const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "aliceUser123";
const BOB_UID = "bobUser456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProfilePayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    email: "alice@example.com",
    displayName: "Alice Baloch",
    defaultSourceLang: "BALOCHI",
    defaultTargetLang: "ENGLISH",
    preferredBalochiScript: "BOTH",
    voiceSpeed: 1.0,
    voiceVolume: 1.0,
    themeMode: "DARK",
    totalTranslations: 0,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validTranslationPayload(uid, overrides = {}) {
  return {
    userId: uid,
    sourceLanguage: "BALOCHI",
    targetLanguage: "ENGLISH",
    sourceText: "Hal o ahwal chon ant?",
    translatedText: "How are you doing?",
    balochiLatinText: "Hal o ahwal chon ant?",
    balochiArabicText: "حال و احوال چون انت؟",
    balochiScript: "BOTH",
    mode: "VOICE",
    createdAt: new Date(Date.now() - 1000),
    ...overrides,
  };
}

test("Unauthenticated access: all profile, translation, and log operations fail", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID))
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("translations").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("translations")
      .doc("tr_1")
      .set(validTranslationPayload(ALICE_UID))
  );
});

test("UserProfile: owner create, partial update, and immutability/bounds enforcement", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const profileRef = aliceDb.collection("users").doc(ALICE_UID);

  // Valid create succeeds
  await assertSucceeds(profileRef.set(validProfilePayload(ALICE_UID)));

  // Valid read succeeds
  await assertSucceeds(profileRef.get());

  // Valid partial update succeeds
  await assertSucceeds(
    profileRef.update({
      preferredBalochiScript: "ARABIC",
      voiceSpeed: 1.25,
      totalTranslations: 1,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject identical source & target language
  await assertFails(
    profileRef.update({
      defaultSourceLang: "BALOCHI",
      defaultTargetLang: "BALOCHI",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject immutable createdAt modification
  await assertFails(
    profileRef.update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject ghost field / shadow update
  await assertFails(
    profileRef.update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject invalid voiceSpeed out of range
  await assertFails(
    profileRef.update({
      voiceSpeed: 5.0,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject future timestamp
  await assertFails(
    profileRef.update({
      voiceVolume: 0.8,
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Cross-user isolation: Bob cannot read or write Alice profile or translations", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminDb = context.firestore();
    await adminDb.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID));
    await adminDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("translations")
      .doc("tr_alice")
      .set(validTranslationPayload(ALICE_UID));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hijacked" })
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("translations").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("translations")
      .doc("tr_alice")
      .delete()
  );
  // Cannot list root /users collection
  await assertFails(bobDb.collection("users").get());
});

test("TranslationRecord: Kotlin-aligned create, list, delete, and schema guards", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const trCol = aliceDb.collection("users").doc(ALICE_UID).collection("translations");

  // Empty subcollection list succeeds
  await assertSucceeds(trCol.orderBy("createdAt", "desc").get());

  // Valid create without @DocumentId `id` field
  await assertSucceeds(trCol.doc("tr_1").set(validTranslationPayload(ALICE_UID)));

  // Valid create with optional uncertaintyNote and omitted optional balochi fields
  await assertSucceeds(
    trCol.doc("tr_2").set({
      userId: ALICE_UID,
      sourceLanguage: "ENGLISH",
      targetLanguage: "URDU",
      sourceText: "Good morning",
      translatedText: "صبح بخیر",
      balochiScript: "LATIN",
      mode: "TEXT",
      uncertaintyNote: "No uncertainty",
      createdAt: new Date(Date.now() - 1000),
    })
  );

  // Reject including @DocumentId `id` field in payload
  await assertFails(
    trCol.doc("tr_bad_id").set({
      id: "tr_bad_id",
      ...validTranslationPayload(ALICE_UID),
    })
  );

  // Reject same source & target language
  await assertFails(
    trCol.doc("tr_same_lang").set(
      validTranslationPayload(ALICE_UID, {
        sourceLanguage: "URDU",
        targetLanguage: "URDU",
      })
    )
  );

  // Reject unsupported language
  await assertFails(
    trCol.doc("tr_unsupported_lang").set(
      validTranslationPayload(ALICE_UID, {
        targetLanguage: "FRENCH",
      })
    )
  );

  // Reject updates (immutable history items)
  await assertFails(
    trCol.doc("tr_1").update({ translatedText: "Tampered" })
  );

  // Owner delete succeeds
  await assertSucceeds(trCol.doc("tr_1").delete());
});

test("UsageLog: owner create, list, delete, and bounds enforcement", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const logsCol = aliceDb.collection("users").doc(ALICE_UID).collection("usage_logs");

  await assertSucceeds(
    logsCol.doc("log_1").set({
      userId: ALICE_UID,
      mode: "LIVE",
      sourceLanguage: "BALOCHI",
      targetLanguage: "URDU",
      status: "SUCCESS",
      latencyMs: 840,
      createdAt: new Date(Date.now() - 1000),
    })
  );

  await assertSucceeds(logsCol.get());

  // Reject invalid latency
  await assertFails(
    logsCol.doc("log_bad").set({
      userId: ALICE_UID,
      mode: "LIVE",
      sourceLanguage: "BALOCHI",
      targetLanguage: "URDU",
      status: "SUCCESS",
      latencyMs: -10,
      createdAt: new Date(Date.now() - 1000),
    })
  );
});
