package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GeminiApiKeyStore
import com.example.model.AppLanguage
import com.example.model.BalochiScript
import com.example.model.UserProfile
import com.example.ui.components.containsArabicCharacters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Balochi AI Translator`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Balochi AI Translator", appName)
    }

    @Test
    fun `supported languages are strictly Balochi English and Urdu`() {
        assertEquals(3, AppLanguage.entries.size)
        assertEquals(
            listOf(AppLanguage.BALOCHI, AppLanguage.ENGLISH, AppLanguage.URDU),
            AppLanguage.entries
        )
    }

    @Test
    fun `user profile target language never equals source language`() {
        val profile = UserProfile(
            userId = "test_uid",
            defaultSourceLang = AppLanguage.BALOCHI.name,
            defaultTargetLang = AppLanguage.BALOCHI.name
        )
        assertNotEquals(profile.sourceLanguageEnum(), profile.targetLanguageEnum())
    }

    @Test
    fun `script detection identifies Arabic and Latin text`() {
        assertTrue(containsArabicCharacters("حال و احوال چون انت؟"))
        assertTrue(containsArabicCharacters("آپ کیسے ہیں؟"))
        assertFalse(containsArabicCharacters("Hal o ahwal chon ant?"))
    }

    @Test
    fun `balochi script enum falls back safely on unknown value`() {
        assertEquals(BalochiScript.BOTH, BalochiScript.fromRaw("UNKNOWN_SCRIPT"))
    }

    @Test
    fun `gemini api key store saves masks and clears key locally`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = GeminiApiKeyStore(context)
        store.clearApiKey()
        assertFalse(store.hasCustomKey.value)
        assertEquals("", store.getApiKey())

        store.saveApiKey("  AIzaSyTestKey1234567890  ")
        assertTrue(store.hasCustomKey.value)
        assertEquals("AIzaSyTestKey1234567890", store.getApiKey())
        assertEquals("AIzaSy••••••••7890", store.maskedPreview())

        store.clearApiKey()
        assertFalse(store.hasCustomKey.value)
        assertEquals("", store.maskedPreview())
    }
}
