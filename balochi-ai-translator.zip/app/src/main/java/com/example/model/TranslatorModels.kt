package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class AppLanguage(
    val displayName: String,
    val nativeLabel: String,
    val shortCode: String,
    val isRtl: Boolean
) {
    BALOCHI("Balochi", "بلوچی", "BAL", false),
    ENGLISH("English", "English", "EN", false),
    URDU("Urdu", "اردو", "UR", true);

    companion object {
        fun fromRaw(raw: String?): AppLanguage =
            entries.firstOrNull { it.name == raw } ?: BALOCHI
    }
}

enum class BalochiScript(
    val displayName: String,
    val shortLabel: String
) {
    LATIN("Latin Transliteration", "Latin"),
    ARABIC("Arabic-based Balochi", "عربی"),
    BOTH("Both Scripts", "Both");

    companion object {
        fun fromRaw(raw: String?): BalochiScript =
            entries.firstOrNull { it.name == raw } ?: BOTH
    }
}

enum class ThemeMode(val displayName: String) {
    DARK("Midnight Dark"),
    LIGHT("Daylight"),
    SYSTEM("System Default");

    companion object {
        fun fromRaw(raw: String?): ThemeMode =
            entries.firstOrNull { it.name == raw } ?: DARK
    }
}

enum class TranslationMode(val label: String) {
    VOICE("Voice"),
    LIVE("Live"),
    TEXT("Text");

    companion object {
        fun fromRaw(raw: String?): TranslationMode =
            entries.firstOrNull { it.name == raw } ?: VOICE
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val defaultSourceLang: String = AppLanguage.BALOCHI.name,
    val defaultTargetLang: String = AppLanguage.ENGLISH.name,
    val preferredBalochiScript: String = BalochiScript.BOTH.name,
    val voiceSpeed: Double = 1.0,
    val voiceVolume: Double = 1.0,
    val themeMode: String = ThemeMode.DARK.name,
    val totalTranslations: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun sourceLanguageEnum(): AppLanguage = AppLanguage.fromRaw(defaultSourceLang)
    fun targetLanguageEnum(): AppLanguage {
        val target = AppLanguage.fromRaw(defaultTargetLang)
        return if (target == sourceLanguageEnum()) {
            if (target == AppLanguage.ENGLISH) AppLanguage.BALOCHI else AppLanguage.ENGLISH
        } else target
    }
    fun balochiScriptEnum(): BalochiScript = BalochiScript.fromRaw(preferredBalochiScript)
    fun themeModeEnum(): ThemeMode = ThemeMode.fromRaw(themeMode)
}

@Keep
@IgnoreExtraProperties
data class TranslationRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val sourceLanguage: String = AppLanguage.BALOCHI.name,
    val targetLanguage: String = AppLanguage.ENGLISH.name,
    val sourceText: String = "",
    val translatedText: String = "",
    val balochiLatinText: String? = null,
    val balochiArabicText: String? = null,
    val balochiScript: String = BalochiScript.BOTH.name,
    val mode: String = TranslationMode.VOICE.name,
    val uncertaintyNote: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun sourceLanguageEnum(): AppLanguage = AppLanguage.fromRaw(sourceLanguage)
    fun targetLanguageEnum(): AppLanguage = AppLanguage.fromRaw(targetLanguage)
    fun balochiScriptEnum(): BalochiScript = BalochiScript.fromRaw(balochiScript)
    fun modeEnum(): TranslationMode = TranslationMode.fromRaw(mode)
}

data class TranslationOutput(
    val sourceLanguage: AppLanguage,
    val targetLanguage: AppLanguage,
    val detectedSourceText: String,
    val translatedText: String,
    val balochiLatinText: String? = null,
    val balochiArabicText: String? = null,
    val isUnclear: Boolean = false,
    val uncertaintyReason: String? = null,
    val registerNote: String? = null,
    val latencyMs: Long = 0L
)

enum class LiveSpeaker { PERSON_A, PERSON_B }

data class LiveTurn(
    val id: String,
    val speaker: LiveSpeaker,
    val sourceLanguage: AppLanguage,
    val targetLanguage: AppLanguage,
    val sourceText: String,
    val translatedText: String,
    val balochiLatinText: String? = null,
    val balochiArabicText: String? = null,
    val isUnclear: Boolean = false,
    val uncertaintyReason: String? = null,
    val timestampMs: Long = System.currentTimeMillis()
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
