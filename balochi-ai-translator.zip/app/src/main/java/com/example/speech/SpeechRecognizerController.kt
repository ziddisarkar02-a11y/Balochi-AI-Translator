package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.model.AppLanguage

class SpeechRecognizerController(
    private val context: Context
) {
    private var speechRecognizer: SpeechRecognizer? = null

    fun isNativeSupported(language: AppLanguage): Boolean {
        if (language == AppLanguage.BALOCHI || language == AppLanguage.URDU) {
            // Route Balochi and Urdu directly through Gemini AI Audio Engine for reliable speed and accuracy.
            return false
        }
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun startListening(
        language: AppLanguage,
        onPartialText: (String) -> Unit,
        onFinalText: (String) -> Unit,
        onRmsChanged: (Float) -> Unit,
        onFallbackRequired: (String) -> Unit
    ) {
        if (!isNativeSupported(language)) {
            onFallbackRequired("Native speech recognizer unavailable for ${language.displayName}.")
            return
        }

        stop()

        val recognizer = try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (e: Exception) {
            Log.w(TAG, "createSpeechRecognizer failed", e)
            onFallbackRequired("Native speech recognizer unavailable.")
            return
        }
        speechRecognizer = recognizer

        val localeTag = when (language) {
            AppLanguage.ENGLISH -> "en-US"
            AppLanguage.URDU -> "ur-PK"
            AppLanguage.BALOCHI -> "en-US"
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                onRmsChanged(normalized)
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                Log.w(TAG, "SpeechRecognizer error code: $error")
                onFallbackRequired("Switching to AI Audio capture (code $error).")
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (text.isNotEmpty()) {
                    onFinalText(text)
                } else {
                    onFallbackRequired("No speech recognized by device recognizer.")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (partial.isNotEmpty()) {
                    onPartialText(partial)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startListening failed", e)
            onFallbackRequired("Native speech recognizer failed to start.")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
        }
    }

    fun stop() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        } finally {
            speechRecognizer = null
        }
    }

    private companion object {
        const val TAG = "SpeechRecController"
    }
}
