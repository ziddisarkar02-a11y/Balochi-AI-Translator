package com.example.speech

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

class AudioCaptureManager(
    private val scope: CoroutineScope
) {
    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null
    private val pcmStream = ByteArrayOutputStream()

    @Volatile
    private var isPaused = false

    @Volatile
    private var isCapturing = false

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    @SuppressLint("MissingPermission")
    fun startRecording(
        enableSilenceDetection: Boolean = false,
        onSilenceDetected: (() -> Unit)? = null,
        onError: (String) -> Unit
    ) {
        stopInternal(resetBuffer = true)

        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer == AudioRecord.ERROR || minBuffer == AudioRecord.ERROR_BAD_VALUE) {
            onError("Microphone audio hardware is unavailable on this device.")
            return
        }

        val bufferSize = maxOf(minBuffer * 2, 4096)
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "Microphone permission denied", e)
            onError("Microphone permission is required to record voice.")
            return
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize AudioRecord", e)
            onError("Could not access microphone: ${e.localizedMessage ?: "unknown error"}")
            return
        }

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            onError("Microphone initialization failed. Check if another app is using the mic.")
            return
        }

        audioRecord = recorder
        isPaused = false
        isCapturing = true
        synchronized(pcmStream) {
            pcmStream.reset()
        }

        try {
            recorder.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "startRecording failed", e)
            stopInternal(resetBuffer = true)
            onError("Unable to start recording: ${e.localizedMessage ?: "mic busy"}")
            return
        }

        captureJob = scope.launch(Dispatchers.IO) {
            val buffer = ShortArray(bufferSize / 2)
            var hasSpoken = false
            var silenceMs = 0L
            val startTime = System.currentTimeMillis()

            while (isActive && isCapturing) {
                val readCount = recorder.read(buffer, 0, buffer.size, AudioRecord.READ_NON_BLOCKING)
                if (readCount > 0) {
                    if (isPaused) {
                        _rmsLevel.value = 0f
                        delay(40)
                        continue
                    }

                    var sumSquares = 0.0
                    val byteBuffer = ByteArray(readCount * 2)
                    for (i in 0 until readCount) {
                        val sample = buffer[i]
                        sumSquares += sample.toDouble() * sample.toDouble()
                        byteBuffer[i * 2] = (sample.toInt() and 0xFF).toByte()
                        byteBuffer[i * 2 + 1] = ((sample.toInt() shr 8) and 0xFF).toByte()
                    }
                    synchronized(pcmStream) {
                        if (pcmStream.size() < MAX_PCM_BYTES) {
                            pcmStream.write(byteBuffer)
                        }
                    }

                    val rms = sqrt(sumSquares / readCount).toFloat()
                    val normalized = (rms / 6500f).coerceIn(0f, 1f)
                    _rmsLevel.value = normalized

                    if (enableSilenceDetection && onSilenceDetected != null) {
                        val frameMs = (readCount * 1000L) / SAMPLE_RATE
                        if (normalized > SPEECH_THRESHOLD) {
                            hasSpoken = true
                            silenceMs = 0L
                        } else if (hasSpoken) {
                            silenceMs += frameMs
                            if (silenceMs >= SILENCE_TIMEOUT_MS) {
                                isCapturing = false
                                onSilenceDetected()
                                break
                            }
                        } else if (System.currentTimeMillis() - startTime > INITIAL_IDLE_LIMIT_MS) {
                            // Avoid keeping mic hot indefinitely with no speech
                            silenceMs += frameMs
                        }
                    }
                } else {
                    delay(20)
                }
            }
            _rmsLevel.value = 0f
        }
    }

    fun pause() {
        isPaused = true
        _rmsLevel.value = 0f
    }

    fun resume() {
        isPaused = false
    }

    fun stopAndBuildWav(): ByteArray? {
        val pcmBytes = stopInternal(resetBuffer = false)
        if (pcmBytes.isEmpty()) return null
        return wrapPcmAsWav(pcmBytes, SAMPLE_RATE, CHANNELS, BITS_PER_SAMPLE)
    }

    fun cancel() {
        stopInternal(resetBuffer = true)
    }

    private fun stopInternal(resetBuffer: Boolean): ByteArray {
        isCapturing = false
        isPaused = false
        captureJob?.cancel()
        captureJob = null
        try {
            audioRecord?.let { rec ->
                if (rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    rec.stop()
                }
                rec.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping AudioRecord: ${e.message}")
        } finally {
            audioRecord = null
            _rmsLevel.value = 0f
        }

        return synchronized(pcmStream) {
            val bytes = if (resetBuffer) ByteArray(0) else pcmStream.toByteArray()
            pcmStream.reset()
            bytes
        }
    }

    private fun wrapPcmAsWav(
        pcmData: ByteArray,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1.toShort()) // PCM format
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort((channels * bitsPerSample / 8).toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()
        return header + pcmData
    }

    private companion object {
        const val TAG = "AudioCaptureManager"
        const val SAMPLE_RATE = 16000
        const val CHANNELS = 1
        const val BITS_PER_SAMPLE = 16
        const val MAX_PCM_BYTES = 16 * 1024 * 1024 // ~8 minutes cap well under 20MB Gemini limit
        const val SPEECH_THRESHOLD = 0.08f
        const val SILENCE_TIMEOUT_MS = 1800L
        const val INITIAL_IDLE_LIMIT_MS = 12_000L
    }
}
