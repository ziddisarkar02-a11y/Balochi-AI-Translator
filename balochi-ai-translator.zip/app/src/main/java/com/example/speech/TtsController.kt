package com.example.speech

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.R
import com.example.model.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed interface TtsPlaybackState {
    data object Idle : TtsPlaybackState
    data class Speaking(val text: String, val language: AppLanguage) : TtsPlaybackState
    data class Paused(val text: String, val language: AppLanguage) : TtsPlaybackState
    data class Unavailable(val reason: String) : TtsPlaybackState
}

class TtsController(
    private val context: Context
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    private val _playbackState = MutableStateFlow<TtsPlaybackState>(TtsPlaybackState.Idle)
    val playbackState: StateFlow<TtsPlaybackState> = _playbackState.asStateFlow()

    private var lastText: String = ""
    private var lastLanguage: AppLanguage = AppLanguage.ENGLISH
    private var lastSpeed: Float = 1.0f
    private var lastVolume: Float = 1.0f
    private var currentChunks: List<String> = emptyList()
    private var currentChunkIndex: Int = 0
    private var onCompleteCallback: (() -> Unit)? = null

    override fun onInit(status: Int) {
        isInitialized = status == TextToSpeech.SUCCESS
        if (!isInitialized) {
            Log.e(TAG, "TextToSpeech engine failed to initialize: $status")
            return
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                val idx = utteranceId?.removePrefix("chunk_")?.toIntOrNull() ?: return
                if (idx == currentChunkIndex && _playbackState.value is TtsPlaybackState.Speaking) {
                    if (currentChunkIndex + 1 < currentChunks.size) {
                        currentChunkIndex++
                        speakCurrentChunk()
                    } else {
                        _playbackState.value = TtsPlaybackState.Idle
                        val doneCb = onCompleteCallback
                        onCompleteCallback = null
                        doneCb?.invoke()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _playbackState.value = TtsPlaybackState.Unavailable("Audio playback failed.")
                onCompleteCallback = null
            }
        })
    }

    fun speak(
        text: String,
        language: AppLanguage,
        speed: Float = 1.0f,
        volume: Float = 1.0f,
        onComplete: (() -> Unit)? = null
    ) {
        val clean = text.trim()
        if (clean.isEmpty()) return

        if (!isInitialized || tts == null) {
            _playbackState.value = TtsPlaybackState.Unavailable(
                "Text-to-Speech engine is not ready on this device."
            )
            onComplete?.invoke()
            return
        }

        val localeResult = resolveSupportedLocale(language)
        if (localeResult == null) {
            val fallbackMessage = when (language) {
                AppLanguage.BALOCHI -> context.getString(R.string.balochi_tts_unavailable)
                AppLanguage.URDU -> context.getString(R.string.urdu_tts_unavailable)
                AppLanguage.ENGLISH -> "English voice synthesis is unavailable on this device."
            }
            _playbackState.value = TtsPlaybackState.Unavailable(fallbackMessage)
            onComplete?.invoke()
            return
        }

        tts?.language = localeResult
        lastText = clean
        lastLanguage = language
        lastSpeed = speed.coerceIn(0.5f, 2.0f)
        lastVolume = volume.coerceIn(0.0f, 1.0f)
        onCompleteCallback = onComplete

        currentChunks = splitIntoSpeakableChunks(clean)
        currentChunkIndex = 0
        _playbackState.value = TtsPlaybackState.Speaking(clean, language)
        speakCurrentChunk()
    }

    fun pause() {
        if (_playbackState.value is TtsPlaybackState.Speaking) {
            tts?.stop()
            _playbackState.value = TtsPlaybackState.Paused(lastText, lastLanguage)
        }
    }

    fun resume() {
        if (_playbackState.value is TtsPlaybackState.Paused && currentChunks.isNotEmpty()) {
            _playbackState.value = TtsPlaybackState.Speaking(lastText, lastLanguage)
            speakCurrentChunk()
        }
    }

    fun replay() {
        if (lastText.isNotEmpty()) {
            speak(lastText, lastLanguage, lastSpeed, lastVolume, onCompleteCallback)
        }
    }

    fun stop() {
        onCompleteCallback = null
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        _playbackState.value = TtsPlaybackState.Idle
    }

    fun clearUnavailableNotice() {
        if (_playbackState.value is TtsPlaybackState.Unavailable) {
            _playbackState.value = TtsPlaybackState.Idle
        }
    }

    fun shutdown() {
        onCompleteCallback = null
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        } finally {
            tts = null
            isInitialized = false
        }
    }

    private fun speakCurrentChunk() {
        val engine = tts ?: return
        if (currentChunkIndex >= currentChunks.size) return
        engine.setSpeechRate(lastSpeed)
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, lastVolume)
        }
        engine.speak(
            currentChunks[currentChunkIndex],
            TextToSpeech.QUEUE_FLUSH,
            params,
            "chunk_$currentChunkIndex"
        )
    }

    private fun resolveSupportedLocale(language: AppLanguage): Locale? {
        val engine = tts ?: return null
        val candidates = when (language) {
            AppLanguage.ENGLISH -> listOf(Locale.US, Locale.UK, Locale.ENGLISH)
            AppLanguage.URDU -> listOf(Locale("ur", "PK"), Locale("ur", "IN"), Locale("ur"))
            AppLanguage.BALOCHI -> listOf(Locale("bal"), Locale("bcc"), Locale("bgn"))
        }
        return candidates.firstOrNull { locale ->
            val avail = engine.isLanguageAvailable(locale)
            avail == TextToSpeech.LANG_AVAILABLE ||
                avail == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
                avail == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
        }
    }

    private fun splitIntoSpeakableChunks(text: String): List<String> {
        val rawSentences = text.split(Regex("(?<=[.!?۔؟\\n])\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        return if (rawSentences.isEmpty()) listOf(text) else rawSentences
    }

    private companion object {
        const val TAG = "TtsController"
    }
}
