package com.example.data

import android.content.Context
import com.example.R
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.example.model.AppLanguage
import com.example.model.BalochiScript
import com.example.model.ThemeMode
import com.example.model.TranslationMode
import com.example.model.TranslationOutput
import com.example.model.TranslationRecord
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUid: String? = null): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        if (expectedUid != null) {
            check(uid == expectedUid) { "Authenticated user changed; refusing cross-user access." }
        }
        return uid
    }

    suspend fun ensureUserProfile(user: FirebaseUser): Result<Unit> {
        val path = "users/${user.uid}"
        return try {
            val uid = requireUserId(user.uid)
            val docRef = db.collection("users").document(uid)
            val snapshot = docRef.get().await()
            val safeEmail = (user.email ?: "").take(320)
            val safeName = (user.displayName?.takeIf { it.isNotBlank() }
                ?: safeEmail.substringBefore("@").ifBlank { "Balochi Translator User" }).take(120)

            if (!snapshot.exists()) {
                val payload = mapOf(
                    "userId" to uid,
                    "email" to safeEmail,
                    "displayName" to safeName,
                    "defaultSourceLang" to AppLanguage.BALOCHI.name,
                    "defaultTargetLang" to AppLanguage.ENGLISH.name,
                    "preferredBalochiScript" to BalochiScript.BOTH.name,
                    "voiceSpeed" to 1.0,
                    "voiceVolume" to 1.0,
                    "themeMode" to ThemeMode.DARK.name,
                    "totalTranslations" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val currentEmail = snapshot.getString("email").orEmpty()
                val currentName = snapshot.getString("displayName").orEmpty()
                if (currentEmail != safeEmail || currentName != safeName) {
                    docRef.update(
                        mapOf(
                            "email" to safeEmail,
                            "displayName" to safeName,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfile> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: UserProfile(userId = uid)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun updatePreferences(
        userId: String,
        defaultSourceLang: AppLanguage,
        defaultTargetLang: AppLanguage,
        preferredBalochiScript: BalochiScript,
        voiceSpeed: Double,
        voiceVolume: Double,
        themeMode: ThemeMode
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            require(defaultSourceLang != defaultTargetLang) {
                "Source and target languages must be different."
            }
            val clampedSpeed = voiceSpeed.coerceIn(0.5, 2.0)
            val clampedVolume = voiceVolume.coerceIn(0.0, 1.0)
            db.collection("users").document(uid).update(
                mapOf(
                    "defaultSourceLang" to defaultSourceLang.name,
                    "defaultTargetLang" to defaultTargetLang.name,
                    "preferredBalochiScript" to preferredBalochiScript.name,
                    "voiceSpeed" to clampedSpeed,
                    "voiceVolume" to clampedVolume,
                    "themeMode" to themeMode.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeTranslations(userId: String): Flow<List<TranslationRecord>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/translations"
        emitAll(
            db.collection("users").document(uid)
                .collection("translations")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(200)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        TranslationRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveTranslation(
        userId: String,
        output: TranslationOutput,
        script: BalochiScript,
        mode: TranslationMode
    ): Result<String> {
        var docPath = "users/$userId/translations"
        return try {
            val uid = requireUserId(userId)
            require(output.sourceLanguage != output.targetLanguage) {
                "Source and target language cannot match."
            }
            val cleanSource = output.detectedSourceText.trim().take(5000)
            val cleanTranslated = output.translatedText.trim().take(5000)
            require(cleanSource.isNotEmpty() && cleanTranslated.isNotEmpty()) {
                "Source and translated text cannot be empty."
            }

            val docRef = db.collection("users").document(uid)
                .collection("translations").document()
            docPath = docRef.path

            val payload = mapOf<String, Any?>(
                "userId" to uid,
                "sourceLanguage" to output.sourceLanguage.name,
                "targetLanguage" to output.targetLanguage.name,
                "sourceText" to cleanSource,
                "translatedText" to cleanTranslated,
                "balochiLatinText" to output.balochiLatinText?.trim()?.take(5000)?.takeIf { it.isNotEmpty() },
                "balochiArabicText" to output.balochiArabicText?.trim()?.take(5000)?.takeIf { it.isNotEmpty() },
                "balochiScript" to script.name,
                "mode" to mode.name,
                "uncertaintyNote" to output.uncertaintyReason?.trim()?.take(1000)?.takeIf { it.isNotEmpty() },
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            val batch = db.batch()
            batch.set(docRef, payload)
            batch.update(
                db.collection("users").document(uid),
                mapOf(
                    "totalTranslations" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteTranslation(userId: String, translationId: String): Result<Unit> {
        val path = "users/$userId/translations/$translationId"
        return try {
            val uid = requireUserId(userId)
            require(translationId.isNotBlank()) { "Translation ID cannot be blank." }
            db.collection("users").document(uid)
                .collection("translations").document(translationId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun clearHistory(userId: String): Result<Unit> {
        val path = "users/$userId/translations"
        return try {
            val uid = requireUserId(userId)
            val docs = db.collection("users").document(uid)
                .collection("translations")
                .get()
                .await()
                .documents
            docs.chunked(400).forEach { chunk ->
                val batch = db.batch()
                chunk.forEach { doc -> batch.delete(doc.reference) }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun logUsageEvent(
        userId: String,
        mode: TranslationMode,
        sourceLanguage: AppLanguage,
        targetLanguage: AppLanguage,
        status: String,
        latencyMs: Long,
        errorMessage: String? = null
    ) {
        if (sourceLanguage == targetLanguage) return
        val path = "users/$userId/usage_logs"
        try {
            val uid = auth.currentUser?.uid ?: return
            if (uid != userId) return
            val docRef = db.collection("users").document(uid)
                .collection("usage_logs").document()
            val payload = mapOf<String, Any?>(
                "userId" to uid,
                "mode" to mode.name,
                "sourceLanguage" to sourceLanguage.name,
                "targetLanguage" to targetLanguage.name,
                "status" to status,
                "latencyMs" to latencyMs.coerceIn(0L, 120_000L),
                "errorMessage" to errorMessage?.trim()?.take(500)?.takeIf { it.isNotEmpty() },
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
        }
    }
}
