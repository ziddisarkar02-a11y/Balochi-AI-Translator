package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Stores an optional user-provided Gemini API key strictly locally on-device
 * in private SharedPreferences. Never written to Firestore or logged.
 */
class GeminiApiKeyStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _hasCustomKey = MutableStateFlow(getApiKey().isNotBlank())
    val hasCustomKey: StateFlow<Boolean> = _hasCustomKey.asStateFlow()

    fun getApiKey(): String = prefs.getString(KEY_GEMINI_API, "").orEmpty().trim()

    fun saveApiKey(apiKey: String) {
        val clean = apiKey.trim()
        prefs.edit().putString(KEY_GEMINI_API, clean).commit()
        _hasCustomKey.value = clean.isNotBlank()
    }

    fun clearApiKey() {
        prefs.edit()
            .remove(KEY_GEMINI_API)
            .remove(KEY_PREFERRED_MODEL)
            .commit()
        _hasCustomKey.value = false
    }

    fun getPreferredModel(): String? =
        prefs.getString(KEY_PREFERRED_MODEL, null)?.trim()?.takeIf { it.isNotEmpty() }

    fun savePreferredModel(modelId: String) {
        prefs.edit().putString(KEY_PREFERRED_MODEL, modelId).apply()
    }

    fun maskedPreview(): String {
        val key = getApiKey()
        if (key.isBlank()) return ""
        return if (key.length <= 10) {
            "••••••••"
        } else {
            "${key.take(6)}••••••••${key.takeLast(4)}"
        }
    }

    private companion object {
        const val PREFS_NAME = "balochi_ai_local_secrets"
        const val KEY_GEMINI_API = "user_gemini_api_key"
        const val KEY_PREFERRED_MODEL = "preferred_gemini_model"
    }
}
