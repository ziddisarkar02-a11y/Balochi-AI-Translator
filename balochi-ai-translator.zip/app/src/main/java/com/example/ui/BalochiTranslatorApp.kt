package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.MicNone
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.ai.BalochiTranslationService
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.FirestoreRepository
import com.example.data.GeminiApiKeyStore
import com.example.model.ThemeMode
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.speech.AudioCaptureManager
import com.example.speech.SpeechRecognizerController
import com.example.speech.TtsController
import com.example.ui.components.GeminiApiKeyDialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.LiveConversationScreen
import com.example.ui.screens.SettingsAndProfileSheet
import com.example.ui.screens.TextTranslatorScreen
import com.example.ui.screens.VoiceTranslatorScreen
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BalochiTranslatorTheme
import com.example.ui.theme.EmeraldSuccess
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val ROUTE_VOICE = "voice_translator"
private const val ROUTE_LIVE = "live_conversation"
private const val ROUTE_TEXT = "text_translator"
private const val ROUTE_HISTORY = "translation_history"

private enum class TranslatorTab(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    VOICE(ROUTE_VOICE, R.string.tab_voice, Icons.Filled.Mic, Icons.Outlined.MicNone),
    LIVE(ROUTE_LIVE, R.string.tab_live, Icons.Filled.GraphicEq, Icons.Outlined.GraphicEq),
    TEXT(ROUTE_TEXT, R.string.tab_text, Icons.Filled.Translate, Icons.Outlined.Translate),
    HISTORY(ROUTE_HISTORY, R.string.tab_history, Icons.Filled.History, Icons.Outlined.History)
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    val user = currentUser
    if (user == null) {
        BalochiTranslatorTheme(themeMode = ThemeMode.DARK) {
            AuthScreen(onAuthSuccess = {})
        }
    } else {
        val uid = user.uid
        key(uid) {
            AuthenticatedTranslatorShell(currentUserId = uid)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedTranslatorShell(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: TranslatorViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                val repo = FirestoreRepository(db)
                val apiKeyStore = GeminiApiKeyStore(app)
                val aiService = BalochiTranslationService(apiKeyStore)
                val captureScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
                val audioCapture = AudioCaptureManager(captureScope)
                val speechRecognizer = SpeechRecognizerController(app)
                val ttsController = TtsController(app)
                TranslatorViewModel(
                    repository = repo,
                    aiService = aiService,
                    apiKeyStore = apiKeyStore,
                    audioCapture = audioCapture,
                    speechRecognizer = speechRecognizer,
                    ttsController = ttsController,
                    currentUserId = currentUserId
                )
            }
        }
    )

    val profileState by viewModel.userProfileState.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val hasCustomApiKey by viewModel.hasCustomApiKey.collectAsStateWithLifecycle()
    val apiKeyValidationState by viewModel.apiKeyValidationState.collectAsStateWithLifecycle()

    val currentProfile = (profileState as? UiState.Success)?.data
        ?: UserProfile(userId = currentUserId)
    val themeMode = currentProfile.themeModeEnum()

    BalochiTranslatorTheme(themeMode = themeMode) {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = navBackStackEntry?.destination
        val snackbarHostState = remember { SnackbarHostState() }
        var showSettingsSheet by remember { mutableStateOf(false) }
        var showApiKeyDialog by remember { mutableStateOf(false) }

        LaunchedEffect(statusBanner) {
            val msg = statusBanner
            if (!msg.isNullOrBlank()) {
                snackbarHostState.showSnackbar(msg)
                viewModel.clearStatusBanner()
            }
        }

        val navigateToTab: (TranslatorTab) -> Unit = { tab ->
            navController.navigate(tab.route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
        ) {
            val useNavigationRail = maxWidth >= 680.dp

            Scaffold(
                containerColor = androidx.compose.ui.graphics.Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.88f)
                        ),
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(
                                    painter = painterResource(id = R.drawable.app_icon_emblem_1794933761946),
                                    contentDescription = "Balochi AI Translator logo",
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = {
                                    viewModel.resetApiKeyValidationState()
                                    showApiKeyDialog = true
                                },
                                modifier = Modifier.testTag("top_api_key_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Key,
                                    contentDescription = "Configure Gemini API Key",
                                    tint = if (hasCustomApiKey) EmeraldSuccess else AmberWarning
                                )
                            }
                            IconButton(
                                onClick = { navigateToTab(TranslatorTab.HISTORY) },
                                modifier = Modifier.testTag("top_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.History,
                                    contentDescription = stringResource(R.string.cd_open_history),
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(
                                onClick = { showSettingsSheet = true },
                                modifier = Modifier.testTag("top_settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Settings,
                                    contentDescription = stringResource(R.string.cd_open_settings),
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(
                                onClick = { showSettingsSheet = true },
                                modifier = Modifier.testTag("top_profile_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AccountCircle,
                                    contentDescription = "User Profile",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                        ) {
                            TranslatorTab.entries.forEach { tab ->
                                val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                                val label = stringResource(tab.labelRes)
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavigationRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            Spacer(modifier = Modifier.weight(0.2f))
                            TranslatorTab.entries.forEach { tab ->
                                val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                                val label = stringResource(tab.labelRes)
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}")
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }

                    val showSnackbar: (String) -> Unit = { msg ->
                        scope.launch { snackbarHostState.showSnackbar(msg) }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        val openApiKeyDialog: () -> Unit = {
                            viewModel.resetApiKeyValidationState()
                            showApiKeyDialog = true
                        }

                        NavHost(
                            navController = navController,
                            startDestination = ROUTE_VOICE
                        ) {
                            composable(ROUTE_VOICE) {
                                VoiceTranslatorScreen(
                                    viewModel = viewModel,
                                    onShowMessage = showSnackbar,
                                    onOpenApiKeyDialog = openApiKeyDialog
                                )
                            }
                            composable(ROUTE_LIVE) {
                                LiveConversationScreen(
                                    viewModel = viewModel,
                                    onShowMessage = showSnackbar,
                                    onOpenApiKeyDialog = openApiKeyDialog
                                )
                            }
                            composable(ROUTE_TEXT) {
                                TextTranslatorScreen(
                                    viewModel = viewModel,
                                    onShowMessage = showSnackbar,
                                    onOpenApiKeyDialog = openApiKeyDialog
                                )
                            }
                            composable(ROUTE_HISTORY) {
                                HistoryScreen(
                                    viewModel = viewModel,
                                    onOpenRecord = { record ->
                                        viewModel.openHistoryRecordInText(record)
                                        navigateToTab(TranslatorTab.TEXT)
                                    },
                                    onShowMessage = showSnackbar
                                )
                            }
                        }
                    }
                }
            }
        }

        val maskedPreview = remember(hasCustomApiKey, apiKeyValidationState) {
            viewModel.apiKeyMaskedPreview()
        }

        if (showSettingsSheet) {
            SettingsAndProfileSheet(
                profile = currentProfile,
                hasCustomApiKey = hasCustomApiKey,
                apiKeyMaskedPreview = maskedPreview,
                onOpenApiKeyDialog = {
                    viewModel.resetApiKeyValidationState()
                    showApiKeyDialog = true
                },
                onDismiss = { showSettingsSheet = false },
                onSavePreferences = { src, tgt, script, speed, vol, theme ->
                    viewModel.saveUserPreferences(src, tgt, script, speed, vol, theme)
                },
                onClearHistory = { viewModel.clearAllHistory() },
                onSignOut = {
                    showSettingsSheet = false
                    viewModel.stopAllAudioAndCaptures()
                    signOut(credentialManager = credentialManager, scope = scope)
                }
            )
        }

        if (showApiKeyDialog) {
            GeminiApiKeyDialog(
                hasExistingKey = hasCustomApiKey,
                maskedPreview = maskedPreview,
                validationState = apiKeyValidationState,
                onVerifyAndSave = { key -> viewModel.verifyAndSaveApiKey(key) },
                onClearKey = { viewModel.clearCustomApiKey() },
                onDismiss = {
                    showApiKeyDialog = false
                    viewModel.resetApiKeyValidationState()
                }
            )
        }
    }
}
