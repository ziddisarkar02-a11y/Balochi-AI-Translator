package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.BalochiScript
import com.example.model.TranslationOutput
import com.example.speech.TtsPlaybackState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.ArabicScriptTextStyle
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LuminousCyan
import com.example.ui.theme.SoftViolet
import kotlin.math.sin

@Composable
fun LanguageSelectorBar(
    sourceLanguage: AppLanguage,
    targetLanguage: AppLanguage,
    onSelectSource: (AppLanguage) -> Unit,
    onSelectTarget: (AppLanguage) -> Unit,
    onSwap: () -> Unit,
    leftLabel: String = stringResource(R.string.label_from),
    rightLabel: String = stringResource(R.string.label_to),
    showQuickTargets: Boolean = true,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.78f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LanguageDropdownPill(
                    label = leftLabel,
                    selected = sourceLanguage,
                    excluded = null,
                    onSelected = { newSrc ->
                        if (newSrc == targetLanguage) {
                            onSwap()
                        } else {
                            onSelectSource(newSrc)
                        }
                    },
                    testTag = "source_language_selector",
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = onSwap,
                    modifier = Modifier
                        .padding(horizontal = 6.dp)
                        .minimumInteractiveComponentSize()
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
                        .testTag("swap_languages_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.SwapHoriz,
                        contentDescription = stringResource(R.string.cd_swap_languages),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                LanguageDropdownPill(
                    label = rightLabel,
                    selected = targetLanguage,
                    excluded = sourceLanguage,
                    onSelected = onSelectTarget,
                    testTag = "target_language_selector",
                    modifier = Modifier.weight(1f)
                )
            }

            if (showQuickTargets) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val isTarget = lang == targetLanguage
                        FilterChip(
                            selected = isTarget,
                            onClick = {
                                if (lang == sourceLanguage) {
                                    onSwap()
                                } else if (!isTarget) {
                                    onSelectTarget(lang)
                                }
                            },
                            label = {
                                Text(
                                    text = lang.displayName,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isTarget) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("quick_target_${lang.name.lowercase()}")
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LanguageDropdownPill(
    label: String,
    selected: AppLanguage,
    excluded: AppLanguage?,
    onSelected: (AppLanguage) -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        Surface(
            onClick = { expanded = true },
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.65f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag(testTag)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = selected.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Choose $label language",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = selected.nativeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            AppLanguage.entries.forEach { lang ->
                val isDisabled = lang == excluded
                DropdownMenuItem(
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = lang.displayName,
                                fontWeight = if (lang == selected) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                text = lang.nativeLabel,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    enabled = !isDisabled,
                    onClick = {
                        expanded = false
                        onSelected(lang)
                    }
                )
            }
        }
    }
}

@Composable
fun BalochiScriptSelectorRow(
    selectedScript: BalochiScript,
    onSelectScript: (BalochiScript) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BalochiScript.entries.forEach { script ->
            val selected = script == selectedScript
            FilterChip(
                selected = selected,
                onClick = { onSelectScript(script) },
                label = {
                    Text(
                        text = script.shortLabel,
                        style = MaterialTheme.typography.labelLarge
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.testTag("script_chip_${script.name.lowercase()}")
            )
        }
    }
}

@Composable
fun AudioWaveformCanvas(
    rmsLevel: Float,
    isActive: Boolean,
    isPaused: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val tertiaryColor = MaterialTheme.colorScheme.tertiary

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
    ) {
        val barCount = 28
        val totalWidth = size.width
        val slotWidth = totalWidth / barCount
        val barWidth = (slotWidth * 0.52f).coerceAtLeast(4f)
        val centerY = size.height / 2f
        val maxBarHeight = size.height * 0.88f

        for (i in 0 until barCount) {
            val normalizedPos = i.toFloat() / barCount
            val envelope = 1f - kotlin.math.abs(normalizedPos - 0.5f) * 1.4f
            val waveOffset = if (isActive && !isPaused) {
                (sin(phase + i * 0.45f) + 1f) * 0.5f
            } else {
                0.2f
            }
            val dynamicLevel = if (isActive && !isPaused) {
                (0.18f + rmsLevel * 0.82f) * (0.45f + 0.55f * waveOffset) * envelope.coerceAtLeast(0.3f)
            } else if (isPaused) {
                0.15f
            } else {
                0.08f
            }

            val barHeight = (maxBarHeight * dynamicLevel).coerceAtLeast(6f)
            val left = i * slotWidth + (slotWidth - barWidth) / 2f
            val barColor = when {
                !isActive -> primaryColor.copy(alpha = 0.25f)
                isPaused -> AmberWarning.copy(alpha = 0.65f)
                i % 3 == 0 -> primaryColor
                i % 3 == 1 -> secondaryColor
                else -> tertiaryColor
            }

            drawRoundRect(
                color = barColor,
                topLeft = Offset(left, centerY - barHeight / 2f),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}

@Composable
fun GlowingMicButton(
    isRecording: Boolean,
    isPaused: Boolean,
    isProcessing: Boolean,
    rmsLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "micPulse")
    val idlePulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            animation = tween(1300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idlePulse"
    )

    val outerScale = when {
        isRecording && !isPaused -> 1.05f + (rmsLevel * 0.28f)
        isProcessing -> idlePulse
        else -> 1f
    }

    val ringColor by animateColorAsState(
        targetValue = when {
            isRecording && isPaused -> AmberWarning
            isRecording -> LuminousCyan
            isProcessing -> SoftViolet
            else -> ElectricBlue
        },
        label = "ringColor"
    )

    Box(
        modifier = modifier.size(136.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(124.dp)
                .scale(outerScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            ringColor.copy(alpha = if (isRecording) 0.42f else 0.22f),
                            Color.Transparent
                        )
                    )
                )
        )

        Surface(
            onClick = onClick,
            enabled = !isProcessing,
            shape = CircleShape,
            color = Color.Transparent,
            modifier = Modifier
                .size(92.dp)
                .border(
                    width = 2.dp,
                    brush = Brush.linearGradient(listOf(LuminousCyan, ElectricBlue, SoftViolet)),
                    shape = CircleShape
                )
                .testTag("central_mic_button")
        ) {
            Box(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            colors = if (isRecording) {
                                listOf(Color(0xFF0EA5E9), Color(0xFF6366F1))
                            } else {
                                listOf(Color(0xFF132245), Color(0xFF1D3566))
                            }
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Rounded.Stop else Icons.Rounded.Mic,
                    contentDescription = if (isRecording) "Stop recording" else "Tap to speak",
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }
        }
    }
}

@Composable
fun TranslationOutputCard(
    output: TranslationOutput,
    ttsState: TtsPlaybackState,
    onPlayAudio: (String, AppLanguage) -> Unit,
    onPauseAudio: () -> Unit,
    onResumeAudio: () -> Unit,
    onStopAudio: () -> Unit,
    onReplayAudio: () -> Unit,
    onCopy: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isSpeakingThis = (ttsState as? TtsPlaybackState.Speaking)?.text == output.translatedText
    val isPausedThis = (ttsState as? TtsPlaybackState.Paused)?.text == output.translatedText

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
        border = BorderStroke(
            1.dp,
            if (output.isUnclear) AmberWarning.copy(alpha = 0.7f)
            else MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (output.isUnclear && !output.uncertaintyReason.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = AmberWarning.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.WarningAmber,
                            contentDescription = "Clarification needed",
                            tint = AmberWarning,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = output.uncertaintyReason,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${output.targetLanguage.displayName} Translation",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onCopy(output.translatedText) },
                        modifier = Modifier.testTag("copy_translation_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "Copy translation",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (isSpeakingThis) {
                        IconButton(onClick = onPauseAudio, modifier = Modifier.testTag("tts_pause_button")) {
                            Icon(Icons.Filled.Pause, contentDescription = "Pause speech", tint = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = onStopAudio, modifier = Modifier.testTag("tts_stop_button")) {
                            Icon(Icons.Filled.Stop, contentDescription = "Stop speech", tint = MaterialTheme.colorScheme.error)
                        }
                    } else if (isPausedThis) {
                        IconButton(onClick = onResumeAudio, modifier = Modifier.testTag("tts_resume_button")) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Resume speech", tint = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = onStopAudio, modifier = Modifier.testTag("tts_stop_button")) {
                            Icon(Icons.Filled.Stop, contentDescription = "Stop speech", tint = MaterialTheme.colorScheme.error)
                        }
                    } else {
                        IconButton(
                            onClick = { onPlayAudio(output.translatedText, output.targetLanguage) },
                            modifier = Modifier.testTag("tts_play_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Listen to translation",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onReplayAudio, modifier = Modifier.testTag("tts_replay_button")) {
                            Icon(
                                imageVector = Icons.Filled.Replay,
                                contentDescription = "Replay last translation",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            DirectionalScriptText(
                text = output.translatedText,
                isRtl = output.targetLanguage.isRtl || containsArabicCharacters(output.translatedText),
                isPrimary = true
            )

            // Show alternate Balochi script when available
            val showLatin = !output.balochiLatinText.isNullOrBlank() &&
                output.balochiLatinText != output.translatedText &&
                output.balochiLatinText != output.detectedSourceText
            val showArabic = !output.balochiArabicText.isNullOrBlank() &&
                output.balochiArabicText != output.translatedText &&
                output.balochiArabicText != output.detectedSourceText

            if (showLatin || showArabic) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.65f))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (showLatin) {
                        Text(
                            text = "Balochi (Latin): ${output.balochiLatinText}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (showArabic) {
                        Text(
                            text = "بلوچی (عربی):",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        DirectionalScriptText(
                            text = output.balochiArabicText.orEmpty(),
                            isRtl = true,
                            isPrimary = false
                        )
                    }
                }
            }

            if (!output.registerNote.isNullOrBlank()) {
                Text(
                    text = output.registerNote,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (ttsState is TtsPlaybackState.Unavailable) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                ) {
                    Text(
                        text = ttsState.reason,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DirectionalScriptText(
    text: String,
    isRtl: Boolean,
    isPrimary: Boolean,
    modifier: Modifier = Modifier
) {
    val direction = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        Text(
            text = text,
            style = when {
                isRtl -> ArabicScriptTextStyle.copy(
                    color = MaterialTheme.colorScheme.onSurface
                )
                isPrimary -> MaterialTheme.typography.titleLarge.copy(
                    color = MaterialTheme.colorScheme.onSurface
                )
                else -> MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            modifier = modifier.fillMaxWidth()
        )
    }
}

fun containsArabicCharacters(text: String): Boolean =
    text.any { ch -> ch in '\u0600'..'\u06FF' || ch in '\u0750'..'\u077F' }
