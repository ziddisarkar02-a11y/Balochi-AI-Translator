package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.AppLanguage
import com.example.ui.TranslatorViewModel
import com.example.ui.components.AudioWaveformCanvas
import com.example.ui.components.BalochiScriptSelectorRow
import com.example.ui.components.DirectionalScriptText
import com.example.ui.components.GlowingMicButton
import com.example.ui.components.LanguageSelectorBar
import com.example.ui.components.TranslationOutputCard
import com.example.ui.components.containsArabicCharacters
import com.example.ui.theme.AmberWarning

@Composable
fun VoiceTranslatorScreen(
    viewModel: TranslatorViewModel,
    onShowMessage: (String) -> Unit,
    onOpenApiKeyDialog: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val audioRms by viewModel.waveformRms.collectAsStateWithLifecycle()
    val nativeRms by viewModel.nativeRms.collectAsStateWithLifecycle()
    val ttsState by viewModel.ttsState.collectAsStateWithLifecycle()
    val hasCustomApiKey by viewModel.hasCustomApiKey.collectAsStateWithLifecycle()

    val effectiveRms = maxOf(audioRms, nativeRms)

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            viewModel.startVoiceRecording()
        } else {
            onShowMessage("Microphone permission is needed for voice translation.")
        }
    }

    var isEditingTranscript by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LanguageSelectorBar(
                sourceLanguage = voiceState.sourceLanguage,
                targetLanguage = voiceState.targetLanguage,
                onSelectSource = { src ->
                    val tgt = if (src == voiceState.targetLanguage) voiceState.sourceLanguage else voiceState.targetLanguage
                    viewModel.setVoiceLanguages(src, tgt)
                },
                onSelectTarget = { tgt ->
                    viewModel.setVoiceLanguages(voiceState.sourceLanguage, tgt)
                },
                onSwap = { viewModel.swapVoiceLanguages() }
            )

            if (voiceState.sourceLanguage == AppLanguage.BALOCHI ||
                voiceState.targetLanguage == AppLanguage.BALOCHI
            ) {
                BalochiScriptSelectorRow(
                    selectedScript = voiceState.balochiScript,
                    onSelectScript = { viewModel.setBalochiScriptQuick(it) }
                )
            }

            if (!hasMicPermission) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = AmberWarning.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MicOff,
                            contentDescription = null,
                            tint = AmberWarning
                        )
                        Text(
                            text = stringResource(R.string.mic_permission_required),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        FilledTonalButton(
                            onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            modifier = Modifier.testTag("grant_mic_permission_button")
                        ) {
                            Text(stringResource(R.string.grant_mic_permission))
                        }
                    }
                }
            }

            // Central Voice Studio Card
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    val engineBadge = when {
                        voiceState.sourceLanguage == AppLanguage.BALOCHI -> "Balochi AI Audio Engine"
                        voiceState.usingAiAudioEngine -> "AI Audio Engine"
                        else -> "Live Speech Captions"
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = engineBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }

                    GlowingMicButton(
                        isRecording = voiceState.isRecording,
                        isPaused = voiceState.isPaused,
                        isProcessing = voiceState.isTranslating,
                        rmsLevel = effectiveRms,
                        onClick = {
                            if (!hasMicPermission) {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            } else if (voiceState.isRecording) {
                                viewModel.finishVoiceRecording()
                            } else {
                                isEditingTranscript = false
                                viewModel.startVoiceRecording()
                            }
                        }
                    )

                    val statusText = when {
                        voiceState.isTranslating -> stringResource(R.string.processing_translation)
                        voiceState.isRecording && voiceState.isPaused -> stringResource(R.string.listening_paused)
                        voiceState.isRecording -> stringResource(R.string.listening_now)
                        else -> stringResource(R.string.tap_to_speak)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (voiceState.isTranslating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    AudioWaveformCanvas(
                        rmsLevel = effectiveRms,
                        isActive = voiceState.isRecording,
                        isPaused = voiceState.isPaused
                    )

                    AnimatedVisibility(visible = voiceState.isRecording) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (voiceState.usingAiAudioEngine) {
                                FilledTonalButton(
                                    onClick = {
                                        if (voiceState.isPaused) viewModel.resumeVoiceRecording()
                                        else viewModel.pauseVoiceRecording()
                                    },
                                    modifier = Modifier.testTag("voice_pause_resume_button")
                                ) {
                                    Icon(
                                        imageVector = if (voiceState.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text(if (voiceState.isPaused) "Resume" else "Pause")
                                }
                            }

                            Button(
                                onClick = { viewModel.finishVoiceRecording() },
                                modifier = Modifier.testTag("voice_translate_now_button")
                            ) {
                                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.size(6.dp))
                                Text("Translate")
                            }

                            OutlinedButton(
                                onClick = { viewModel.cancelVoiceRecording() },
                                modifier = Modifier.testTag("voice_cancel_button")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    if (voiceState.livePartialTranscript.isNotBlank() && voiceState.isRecording) {
                        Text(
                            text = voiceState.livePartialTranscript,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (!voiceState.errorMessage.isNullOrBlank()) {
                val isKeyError = !hasCustomApiKey || viewModel.isKeyOrAuthError(voiceState.errorMessage)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = voiceState.errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (voiceState.canRetryAudio) {
                                FilledTonalButton(
                                    onClick = { viewModel.retryLastVoiceTranslation() },
                                    enabled = !voiceState.isTranslating,
                                    modifier = Modifier.testTag("voice_retry_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Refresh,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Retry")
                                }
                            }
                            if (isKeyError) {
                                TextButton(
                                    onClick = onOpenApiKeyDialog,
                                    modifier = Modifier.testTag("error_configure_api_key_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Key,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Add / Update Gemini API Key")
                                }
                            }
                        }
                    }
                }
            }

            // Recognized Transcript Card (Editable so user can correct misheard words)
            if (voiceState.editableTranscript.isNotBlank() && !voiceState.isRecording) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Recognized (${voiceState.sourceLanguage.displayName})",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            IconButton(
                                onClick = { isEditingTranscript = !isEditingTranscript },
                                modifier = Modifier.testTag("edit_transcript_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "Edit recognized sentence",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        if (isEditingTranscript) {
                            OutlinedTextField(
                                value = voiceState.editableTranscript,
                                onValueChange = { viewModel.updateEditableTranscript(it) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("editable_transcript_field"),
                                label = { Text("Correct words if needed") }
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = {
                                        isEditingTranscript = false
                                        viewModel.retranslateEditedTranscript()
                                    },
                                    enabled = !voiceState.isTranslating,
                                    modifier = Modifier.testTag("retranslate_edited_button")
                                ) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Retranslate")
                                }
                            }
                        } else {
                            DirectionalScriptText(
                                text = voiceState.editableTranscript,
                                isRtl = voiceState.sourceLanguage.isRtl ||
                                    containsArabicCharacters(voiceState.editableTranscript),
                                isPrimary = false
                            )
                        }
                    }
                }
            }

            // Translated Output Card
            voiceState.result?.let { output ->
                TranslationOutputCard(
                    output = output,
                    ttsState = ttsState,
                    onPlayAudio = { txt, lang -> viewModel.speakText(txt, lang) },
                    onPauseAudio = { viewModel.pauseSpeech() },
                    onResumeAudio = { viewModel.resumeSpeech() },
                    onStopAudio = { viewModel.stopSpeech() },
                    onReplayAudio = { viewModel.replaySpeech() },
                    onCopy = { txt ->
                        clipboard.setText(AnnotatedString(txt))
                        onShowMessage("Translation copied to clipboard")
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
