package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.LiveSpeaker
import com.example.model.LiveTurn
import com.example.speech.TtsPlaybackState
import com.example.ui.TranslatorViewModel
import com.example.ui.components.AudioWaveformCanvas
import com.example.ui.components.DirectionalScriptText
import com.example.ui.components.LanguageSelectorBar
import com.example.ui.components.containsArabicCharacters
import com.example.ui.theme.AmberWarning

@Composable
fun LiveConversationScreen(
    viewModel: TranslatorViewModel,
    onShowMessage: (String) -> Unit,
    onOpenApiKeyDialog: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val liveState by viewModel.liveState.collectAsStateWithLifecycle()
    val rmsLevel by viewModel.waveformRms.collectAsStateWithLifecycle()
    val ttsState by viewModel.ttsState.collectAsStateWithLifecycle()
    val hasCustomApiKey by viewModel.hasCustomApiKey.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            viewModel.startLiveConversation()
        } else {
            onShowMessage("Microphone permission is required for Live Voice Mode.")
        }
    }

    LaunchedEffect(liveState.turns.size) {
        if (liveState.turns.isNotEmpty()) {
            listState.animateScrollToItem(liveState.turns.lastIndex)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LanguageSelectorBar(
                sourceLanguage = liveState.personALanguage,
                targetLanguage = liveState.personBLanguage,
                leftLabel = "PERSON A",
                rightLabel = "PERSON B",
                onSelectSource = { langA ->
                    val langB = if (langA == liveState.personBLanguage) liveState.personALanguage else liveState.personBLanguage
                    viewModel.setLiveLanguages(langA, langB)
                },
                onSelectTarget = { langB ->
                    viewModel.setLiveLanguages(liveState.personALanguage, langB)
                },
                onSwap = { viewModel.swapLiveSpeakers() },
                showQuickTargets = false
            )

            // Active Speaker Selector Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SpeakerTurnCard(
                    title = "Person A",
                    languageName = liveState.personALanguage.displayName,
                    isActive = liveState.activeSpeaker == LiveSpeaker.PERSON_A,
                    isListening = liveState.isListening && liveState.activeSpeaker == LiveSpeaker.PERSON_A,
                    onClick = { viewModel.selectLiveSpeaker(LiveSpeaker.PERSON_A) },
                    testTag = "speaker_a_card",
                    modifier = Modifier.weight(1f)
                )
                SpeakerTurnCard(
                    title = "Person B",
                    languageName = liveState.personBLanguage.displayName,
                    isActive = liveState.activeSpeaker == LiveSpeaker.PERSON_B,
                    isListening = liveState.isListening && liveState.activeSpeaker == LiveSpeaker.PERSON_B,
                    onClick = { viewModel.selectLiveSpeaker(LiveSpeaker.PERSON_B) },
                    testTag = "speaker_b_card",
                    modifier = Modifier.weight(1f)
                )
            }

            if (!liveState.errorMessage.isNullOrBlank()) {
                val isKeyError = !hasCustomApiKey || viewModel.isKeyOrAuthError(liveState.errorMessage)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = liveState.errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalButton(
                                onClick = { viewModel.resumeLiveConversation() },
                                modifier = Modifier.testTag("live_retry_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text("Retry")
                            }
                            if (isKeyError) {
                                TextButton(
                                    onClick = onOpenApiKeyDialog,
                                    modifier = Modifier.testTag("error_configure_api_key_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Key,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Add / Update Gemini API Key")
                                }
                            }
                        }
                    }
                }
            }

            if (ttsState is TtsPlaybackState.Unavailable) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = (ttsState as TtsPlaybackState.Unavailable).reason,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Live Bilingual Captions Feed
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (liveState.turns.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GraphicEq,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Two-Way Live Interpreter",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap Start Conversation. Person A speaks first, Gemini AI translates and speaks the reply aloud, then automatically hands the turn to Person B.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(liveState.turns, key = { it.id }) { turn ->
                            LiveTurnBubble(
                                turn = turn,
                                onReplayTts = {
                                    viewModel.speakText(turn.translatedText, turn.targetLanguage)
                                }
                            )
                        }
                    }
                }
            }

            // Live Waveform & Control Bar
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (liveState.isSessionActive) {
                        AudioWaveformCanvas(
                            rmsLevel = rmsLevel,
                            isActive = liveState.isListening,
                            isPaused = liveState.isPaused,
                            modifier = Modifier.height(44.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!liveState.isSessionActive) {
                            Button(
                                onClick = {
                                    if (!hasMicPermission) {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        viewModel.startLiveConversation()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("start_live_button")
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.size(6.dp))
                                Text("Start Conversation")
                            }
                        } else {
                            if (liveState.isProcessingTurn) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                    Text("Translating turn…", style = MaterialTheme.typography.labelLarge)
                                }
                            } else {
                                FilledTonalButton(
                                    onClick = {
                                        if (liveState.isPaused) viewModel.resumeLiveConversation()
                                        else viewModel.pauseLiveConversation()
                                    },
                                    modifier = Modifier.testTag("live_pause_resume_button")
                                ) {
                                    Icon(
                                        imageVector = if (liveState.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text(if (liveState.isPaused) "Resume" else "Pause")
                                }

                                if (liveState.isListening) {
                                    Button(
                                        onClick = { viewModel.submitCurrentLiveTurn() },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("live_send_turn_button")
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.size(4.dp))
                                        Text("Send Turn")
                                    }
                                }
                            }

                            OutlinedButton(
                                onClick = { viewModel.stopLiveConversation() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier.testTag("stop_live_button")
                            ) {
                                Icon(Icons.Filled.Stop, contentDescription = "Stop conversation", modifier = Modifier.size(18.dp))
                            }
                        }

                        IconButton(
                            onClick = { viewModel.toggleLiveMute() },
                            modifier = Modifier.testTag("live_mute_button")
                        ) {
                            Icon(
                                imageVector = if (liveState.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = if (liveState.isMuted) "Unmute translated speech" else "Mute translated speech",
                                tint = if (liveState.isMuted) AmberWarning else MaterialTheme.colorScheme.primary
                            )
                        }

                        if (liveState.turns.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.clearLiveConversation() },
                                modifier = Modifier.testTag("live_clear_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteSweep,
                                    contentDescription = "Clear conversation",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SpeakerTurnCard(
    title: String,
    languageName: String,
    isActive: Boolean,
    isListening: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(
            width = if (isActive) 1.5.dp else 1.dp,
            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (isListening) {
                    Text(
                        text = "LIVE",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Text(
                text = languageName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun LiveTurnBubble(
    turn: LiveTurn,
    onReplayTts: () -> Unit
) {
    val isPersonA = turn.speaker == LiveSpeaker.PERSON_A
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isPersonA) MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)
        else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
        border = BorderStroke(
            1.dp,
            if (turn.isUnclear) AmberWarning.copy(alpha = 0.6f)
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${if (isPersonA) "Person A" else "Person B"} • ${turn.sourceLanguage.displayName} → ${turn.targetLanguage.displayName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                IconButton(onClick = onReplayTts, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Speak translation",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            if (turn.isUnclear && !turn.uncertaintyReason.isNullOrBlank()) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.WarningAmber,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = turn.uncertaintyReason,
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberWarning
                    )
                }
            }

            DirectionalScriptText(
                text = turn.sourceText,
                isRtl = turn.sourceLanguage.isRtl || containsArabicCharacters(turn.sourceText),
                isPrimary = false
            )
            DirectionalScriptText(
                text = turn.translatedText,
                isRtl = turn.targetLanguage.isRtl || containsArabicCharacters(turn.translatedText),
                isPrimary = true
            )
        }
    }
}
