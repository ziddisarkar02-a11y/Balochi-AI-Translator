package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.BalochiScript
import com.example.model.ThemeMode
import com.example.model.UserProfile
import com.example.ui.components.LanguageSelectorBar
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldSuccess
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsAndProfileSheet(
    profile: UserProfile,
    hasCustomApiKey: Boolean,
    apiKeyMaskedPreview: String,
    onOpenApiKeyDialog: () -> Unit,
    onDismiss: () -> Unit,
    onSavePreferences: (
        source: AppLanguage,
        target: AppLanguage,
        script: BalochiScript,
        speed: Double,
        volume: Double,
        theme: ThemeMode
    ) -> Unit,
    onClearHistory: () -> Unit,
    onSignOut: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var defaultSource by remember(profile) { mutableStateOf(profile.sourceLanguageEnum()) }
    var defaultTarget by remember(profile) { mutableStateOf(profile.targetLanguageEnum()) }
    var preferredScript by remember(profile) { mutableStateOf(profile.balochiScriptEnum()) }
    var voiceSpeed by remember(profile) { mutableDoubleStateOf(profile.voiceSpeed.coerceIn(0.5, 2.0)) }
    var voiceVolume by remember(profile) { mutableDoubleStateOf(profile.voiceVolume.coerceIn(0.0, 1.0)) }
    var themeMode by remember(profile) { mutableStateOf(profile.themeModeEnum()) }
    var showClearConfirm by remember { mutableStateOf(false) }

    val memberSince = remember(profile.createdAt) {
        val date = profile.createdAt?.toDate()
        if (date != null) SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(date) else "Active"
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Profile & Settings",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close settings")
                }
            }

            // Account Profile Summary Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.78f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = "User avatar",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = profile.displayName.ifBlank { "Google Account User" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (profile.email.isNotBlank()) {
                            Text(
                                text = profile.email,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "Member since $memberSince • ${profile.totalTranslations} translations",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Gemini AI Engine & API Key Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.78f),
                border = BorderStroke(
                    1.dp,
                    if (hasCustomApiKey) EmeraldSuccess.copy(alpha = 0.55f)
                    else AmberWarning.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Key,
                            contentDescription = null,
                            tint = if (hasCustomApiKey) EmeraldSuccess else AmberWarning
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini AI Engine",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (hasCustomApiKey) {
                                    "Custom Gemini API Key active ($apiKeyMaskedPreview)"
                                } else {
                                    "Using Firebase AI Logic (default). Add your Gemini API key if translation is blocked."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    FilledTonalButton(
                        onClick = onOpenApiKeyDialog,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_api_key_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Key,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(if (hasCustomApiKey) "Update or Remove Gemini API Key" else "Add Gemini API Key")
                    }
                }
            }

            Text(
                text = "Default Translation Pair",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            LanguageSelectorBar(
                sourceLanguage = defaultSource,
                targetLanguage = defaultTarget,
                onSelectSource = { src ->
                    if (src == defaultTarget) {
                        defaultTarget = defaultSource
                    }
                    defaultSource = src
                },
                onSelectTarget = { tgt ->
                    if (tgt != defaultSource) defaultTarget = tgt
                },
                onSwap = {
                    val tmp = defaultSource
                    defaultSource = defaultTarget
                    defaultTarget = tmp
                }
            )

            Text(
                text = "Preferred Balochi Script",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                BalochiScript.entries.forEach { script ->
                    FilterChip(
                        selected = preferredScript == script,
                        onClick = { preferredScript = script },
                        label = { Text(script.displayName) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Column {
                Text(
                    text = "Voice Playback Speed: ${String.format(Locale.US, "%.2fx", voiceSpeed)}",
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = voiceSpeed.toFloat(),
                    onValueChange = { voiceSpeed = it.toDouble() },
                    valueRange = 0.5f..2.0f
                )
            }

            Column {
                Text(
                    text = "Voice Volume: ${(voiceVolume * 100).toInt()}%",
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = voiceVolume.toFloat(),
                    onValueChange = { voiceVolume = it.toDouble() },
                    valueRange = 0.0f..1.0f
                )
            }

            Text(
                text = "App Theme",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = themeMode == mode,
                        onClick = { themeMode = mode },
                        label = { Text(mode.displayName) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Button(
                onClick = {
                    onSavePreferences(
                        defaultSource,
                        defaultTarget,
                        preferredScript,
                        voiceSpeed,
                        voiceVolume,
                        themeMode
                    )
                    onDismiss()
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_preferences_button")
            ) {
                Text("Save Preferences")
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { showClearConfirm = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("settings_clear_history_button")
                ) {
                    Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Clear History")
                }

                OutlinedButton(
                    onClick = onSignOut,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(stringResource(R.string.sign_out))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Translation History?") },
            text = { Text("All saved translations in your account will be permanently deleted.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearConfirm = false
                        onClearHistory()
                    }
                ) {
                    Text("Clear All", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
