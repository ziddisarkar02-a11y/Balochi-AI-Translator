package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.BalochiTranslationService
import com.example.data.FirestoreRepository
import com.example.data.GeminiApiKeyStore
import com.example.model.AppLanguage
import com.example.model.BalochiScript
import com.example.model.LiveSpeaker
import com.example.model.LiveTurn
import com.example.model.ThemeMode
import com.example.model.TranslationMode
import com.example.model.TranslationOutput
import com.example.model.TranslationRecord
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.speech.AudioCaptureManager
import com.example.speech.SpeechRecognizerController
import com.example.speech.TtsController
import com.example.speech.TtsPlaybackState
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface ApiKeyValidationState {
    data object Idle : ApiKeyValidationState
    data object Testing : ApiKeyValidationState
    data class Verified(val details: String) : ApiKeyValidationState
    data class Error(val message: String) : ApiKeyValidationState
}

data class VoiceUiState(
    val sourceLanguage: AppLanguage = AppLanguage.BALOCHI,
    val targetLanguage: AppLanguage = AppLanguage.ENGLISH,
    val balochiScript: BalochiScript = BalochiScript.BOTH,
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val isTranslating: Boolean = false,
    val usingAiAudioEngine: Boolean = true,
    val livePartialTranscript: String = "",
    val editableTranscript: String = "",
    val result: TranslationOutput? = null,
    val errorMessage: String? = null,
    val canRetryAudio: Boolean = false
)

data class LiveUiState(
    val personALanguage: AppLanguage = AppLanguage.BALOCHI,
    val personBLanguage: AppLanguage = AppLanguage.ENGLISH,
    val activeSpeaker: LiveSpeaker = LiveSpeaker.PERSON_A,
    val isSessionActive: Boolean = false,
    val isPaused: Boolean = false,
    val isListening: Boolean = false,
    val isProcessingTurn: Boolean = false,
    val isMuted: Boolean = false,
    val turns: List<LiveTurn> = emptyList(),
    val errorMessage: String? = null
)

data class TextUiState(
    val sourceLanguage: AppLanguage = AppLanguage.BALOCHI,
    val targetLanguage: AppLanguage = AppLanguage.ENGLISH,
    val inputText: String = "",
    val isTranslating: Boolean = false,
    val result: TranslationOutput? = null,
    val errorMessage: String? = null
)

class TranslatorViewModel(
    private val repository: FirestoreRepository,
    private val aiService: BalochiTranslationService,
    private val apiKeyStore: GeminiApiKeyStore,
    private val audioCapture: AudioCaptureManager,
    private val speechRecognizer: SpeechRecognizerController,
    private val ttsController: TtsController,
    private val currentUserId: String
) : ViewModel() {

    val hasCustomApiKey: StateFlow<Boolean> = apiKeyStore.hasCustomKey

    private val _apiKeyValidationState =
        MutableStateFlow<ApiKeyValidationState>(ApiKeyValidationState.Idle)
    val apiKeyValidationState: StateFlow<ApiKeyValidationState> =
        _apiKeyValidationState.asStateFlow()

    fun apiKeyMaskedPreview(): String = apiKeyStore.maskedPreview()

    val waveformRms: StateFlow<Float> = audioCapture.rmsLevel
    private val _nativeRms = MutableStateFlow(0f)
    val nativeRms: StateFlow<Float> = _nativeRms.asStateFlow()

    val ttsState: StateFlow<TtsPlaybackState> = ttsController.playbackState

    val userProfileState: StateFlow<UiState<UserProfile>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile, UiState<UserProfile>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing profile", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val historyState: StateFlow<UiState<List<TranslationRecord>>> =
        repository.observeTranslations(currentUserId)
            .map<List<TranslationRecord>, UiState<List<TranslationRecord>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing translations", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to observe translation history"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    private val _voiceState = MutableStateFlow(VoiceUiState())
    val voiceState: StateFlow<VoiceUiState> = _voiceState.asStateFlow()

    private val _liveState = MutableStateFlow(LiveUiState())
    val liveState: StateFlow<LiveUiState> = _liveState.asStateFlow()

    private val _textState = MutableStateFlow(TextUiState())
    val textState: StateFlow<TextUiState> = _textState.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private var appliedInitialPreferences = false
    private var voiceTranslationJob: Job? = null
    private var textTranslationJob: Job? = null
    private var liveTurnJob: Job? = null
    private var usingNativeRecognizerForVoice = false
    private var lastVoiceWavBytes: ByteArray? = null

    init {
        viewModelScope.launch {
            aiService.prewarmConnection()
        }
        viewModelScope.launch {
            Firebase.auth.currentUser?.let { user ->
                if (user.uid == currentUserId) {
                    repository.ensureUserProfile(user)
                }
            }
        }
        viewModelScope.launch {
            userProfileState.collect { state ->
                if (state is UiState.Success) {
                    val profile = state.data
                    val script = profile.balochiScriptEnum()
                    _voiceState.update { it.copy(balochiScript = script) }
                    if (!appliedInitialPreferences) {
                        appliedInitialPreferences = true
                        val src = profile.sourceLanguageEnum()
                        val tgt = profile.targetLanguageEnum()
                        _voiceState.update { it.copy(sourceLanguage = src, targetLanguage = tgt) }
                        _textState.update { it.copy(sourceLanguage = src, targetLanguage = tgt) }
                        _liveState.update { it.copy(personALanguage = src, personBLanguage = tgt) }
                    }
                }
            }
        }
    }

    private fun currentProfile(): UserProfile? =
        (userProfileState.value as? UiState.Success)?.data

    // --- Voice Mode Controls ---

    fun setVoiceLanguages(source: AppLanguage, target: AppLanguage) {
        if (source == target) return
        _voiceState.update { it.copy(sourceLanguage = source, targetLanguage = target, errorMessage = null) }
    }

    fun swapVoiceLanguages() {
        _voiceState.update {
            it.copy(
                sourceLanguage = it.targetLanguage,
                targetLanguage = it.sourceLanguage,
                errorMessage = null
            )
        }
    }

    fun setBalochiScriptQuick(script: BalochiScript) {
        _voiceState.update { it.copy(balochiScript = script) }
        val profile = currentProfile() ?: return
        viewModelScope.launch {
            repository.updatePreferences(
                userId = currentUserId,
                defaultSourceLang = profile.sourceLanguageEnum(),
                defaultTargetLang = profile.targetLanguageEnum(),
                preferredBalochiScript = script,
                voiceSpeed = profile.voiceSpeed,
                voiceVolume = profile.voiceVolume,
                themeMode = profile.themeModeEnum()
            )
        }
    }

    fun startVoiceRecording() {
        if (_voiceState.value.isTranslating) return
        stopAllAudioAndCaptures()
        lastVoiceWavBytes = null
        val src = _voiceState.value.sourceLanguage
        val preferNative = speechRecognizer.isNativeSupported(src)

        _voiceState.update {
            it.copy(
                isRecording = true,
                isPaused = false,
                usingAiAudioEngine = !preferNative,
                livePartialTranscript = "",
                errorMessage = null,
                canRetryAudio = false
            )
        }

        if (preferNative) {
            usingNativeRecognizerForVoice = true
            speechRecognizer.startListening(
                language = src,
                onPartialText = { partial ->
                    _voiceState.update { it.copy(livePartialTranscript = partial) }
                },
                onFinalText = { finalText ->
                    usingNativeRecognizerForVoice = false
                    _nativeRms.value = 0f
                    _voiceState.update {
                        it.copy(
                            isRecording = false,
                            isPaused = false,
                            livePartialTranscript = finalText,
                            editableTranscript = finalText
                        )
                    }
                    translateVoiceText(finalText)
                },
                onRmsChanged = { rms ->
                    _nativeRms.value = rms
                },
                onFallbackRequired = { _ ->
                    // Seamless automatic fallback: use captured partial text if present, otherwise switch to AI Audio Engine
                    val partial = _voiceState.value.livePartialTranscript.trim()
                    usingNativeRecognizerForVoice = false
                    speechRecognizer.stop()
                    _nativeRms.value = 0f
                    if (partial.isNotEmpty()) {
                        _voiceState.update {
                            it.copy(
                                isRecording = false,
                                isPaused = false,
                                editableTranscript = partial
                            )
                        }
                        translateVoiceText(partial)
                    } else {
                        startVoiceAiAudioCapture()
                    }
                }
            )
        } else {
            startVoiceAiAudioCapture()
        }
    }

    private fun startVoiceAiAudioCapture() {
        usingNativeRecognizerForVoice = false
        _voiceState.update {
            it.copy(isRecording = true, isPaused = false, usingAiAudioEngine = true)
        }
        audioCapture.startRecording(
            enableSilenceDetection = false,
            onError = { msg ->
                _voiceState.update {
                    it.copy(isRecording = false, isPaused = false, errorMessage = msg)
                }
            }
        )
    }

    fun pauseVoiceRecording() {
        if (!_voiceState.value.isRecording || _voiceState.value.isPaused) return
        if (usingNativeRecognizerForVoice) {
            // Native SpeechRecognizer does not support true pause; switch to finish
            finishVoiceRecording()
            return
        }
        audioCapture.pause()
        _voiceState.update { it.copy(isPaused = true) }
    }

    fun resumeVoiceRecording() {
        if (!_voiceState.value.isRecording || !_voiceState.value.isPaused) return
        audioCapture.resume()
        _voiceState.update { it.copy(isPaused = false) }
    }

    fun finishVoiceRecording() {
        if (!_voiceState.value.isRecording) return
        if (usingNativeRecognizerForVoice) {
            val partial = _voiceState.value.livePartialTranscript.trim()
            speechRecognizer.stopListening()
            if (partial.isNotEmpty()) {
                usingNativeRecognizerForVoice = false
                speechRecognizer.stop()
                _nativeRms.value = 0f
                _voiceState.update {
                    it.copy(isRecording = false, isPaused = false, editableTranscript = partial)
                }
                translateVoiceText(partial)
            } else {
                _voiceState.update { it.copy(isRecording = false, isPaused = false) }
            }
            return
        }

        val wavBytes = audioCapture.stopAndBuildWav()
        _voiceState.update { it.copy(isRecording = false, isPaused = false) }
        if (wavBytes == null || wavBytes.size <= 44) {
            _voiceState.update {
                it.copy(errorMessage = "No voice audio captured. Please tap the microphone and speak clearly.")
            }
            return
        }
        translateVoiceAudio(wavBytes)
    }

    fun cancelVoiceRecording() {
        usingNativeRecognizerForVoice = false
        speechRecognizer.stop()
        audioCapture.cancel()
        _nativeRms.value = 0f
        _voiceState.update {
            it.copy(isRecording = false, isPaused = false, livePartialTranscript = "")
        }
    }

    fun updateEditableTranscript(newText: String) {
        _voiceState.update { it.copy(editableTranscript = newText) }
    }

    fun retranslateEditedTranscript() {
        val text = _voiceState.value.editableTranscript.trim()
        if (text.isNotEmpty()) {
            translateVoiceText(text)
        }
    }

    fun retryLastVoiceTranslation() {
        val state = _voiceState.value
        if (state.isTranslating || state.isRecording) return
        val pendingAudio = lastVoiceWavBytes
        if (pendingAudio != null && pendingAudio.size > 44) {
            translateVoiceAudio(pendingAudio)
            return
        }
        val text = state.editableTranscript.trim()
        if (text.isNotEmpty()) {
            translateVoiceText(text)
        }
    }

    fun isKeyOrAuthError(message: String?): Boolean {
        if (message.isNullOrBlank()) return false
        return message.contains("API key", ignoreCase = true) ||
            message.contains("AppCheck", ignoreCase = true) ||
            message.contains("App Check", ignoreCase = true) ||
            message.contains("401") ||
            message.contains("403") ||
            message.contains("unauthorized", ignoreCase = true) ||
            message.contains("quota", ignoreCase = true) ||
            message.contains("429")
    }

    private fun translateVoiceAudio(wavBytes: ByteArray) {
        if (voiceTranslationJob?.isActive == true) return
        lastVoiceWavBytes = wavBytes
        val state = _voiceState.value
        voiceTranslationJob = viewModelScope.launch {
            _voiceState.update { it.copy(isTranslating = true, errorMessage = null, canRetryAudio = true) }
            val result = aiService.translateAudio(
                wavAudioBytes = wavBytes,
                sourceLanguage = state.sourceLanguage,
                targetLanguage = state.targetLanguage,
                balochiScript = state.balochiScript
            )
            handleVoiceTranslationResult(result, state.sourceLanguage, state.targetLanguage, state.balochiScript)
        }
    }

    private fun translateVoiceText(text: String) {
        if (voiceTranslationJob?.isActive == true) return
        val state = _voiceState.value
        voiceTranslationJob = viewModelScope.launch {
            _voiceState.update { it.copy(isTranslating = true, errorMessage = null) }
            val result = aiService.translateText(
                text = text,
                sourceLanguage = state.sourceLanguage,
                targetLanguage = state.targetLanguage,
                balochiScript = state.balochiScript
            )
            handleVoiceTranslationResult(result, state.sourceLanguage, state.targetLanguage, state.balochiScript)
        }
    }

    private fun handleVoiceTranslationResult(
        result: Result<TranslationOutput>,
        src: AppLanguage,
        tgt: AppLanguage,
        script: BalochiScript
    ) {
        result.onSuccess { output ->
            lastVoiceWavBytes = null
            _voiceState.update {
                it.copy(
                    isTranslating = false,
                    editableTranscript = output.detectedSourceText,
                    livePartialTranscript = output.detectedSourceText,
                    result = output,
                    errorMessage = null,
                    canRetryAudio = false
                )
            }
            val status = if (output.isUnclear) "UNCLEAR" else "SUCCESS"
            viewModelScope.launch(Dispatchers.IO) {
                repository.logUsageEvent(currentUserId, TranslationMode.VOICE, src, tgt, status, output.latencyMs)
                if (!output.isUnclear) {
                    repository.saveTranslation(currentUserId, output, script, TranslationMode.VOICE)
                }
            }
        }.onFailure { err ->
            val msg = err.localizedMessage ?: "Voice translation failed."
            _voiceState.update {
                it.copy(
                    isTranslating = false,
                    errorMessage = msg,
                    canRetryAudio = lastVoiceWavBytes != null || it.editableTranscript.isNotBlank()
                )
            }
            viewModelScope.launch(Dispatchers.IO) {
                repository.logUsageEvent(currentUserId, TranslationMode.VOICE, src, tgt, "ERROR", 0L, msg)
            }
        }
    }

    // --- Live Conversation Mode ---

    fun setLiveLanguages(personA: AppLanguage, personB: AppLanguage) {
        if (personA == personB) return
        _liveState.update {
            it.copy(personALanguage = personA, personBLanguage = personB, errorMessage = null)
        }
    }

    fun swapLiveSpeakers() {
        _liveState.update {
            it.copy(
                personALanguage = it.personBLanguage,
                personBLanguage = it.personALanguage,
                activeSpeaker = if (it.activeSpeaker == LiveSpeaker.PERSON_A) LiveSpeaker.PERSON_B else LiveSpeaker.PERSON_A,
                errorMessage = null
            )
        }
    }

    fun selectLiveSpeaker(speaker: LiveSpeaker) {
        val current = _liveState.value
        if (current.activeSpeaker == speaker && current.isListening) return
        _liveState.update { it.copy(activeSpeaker = speaker, errorMessage = null) }
        if (current.isSessionActive && !current.isPaused && !current.isProcessingTurn) {
            beginLiveListeningForActiveSpeaker()
        }
    }

    fun toggleLiveMute() {
        val newMuted = !_liveState.value.isMuted
        _liveState.update { it.copy(isMuted = newMuted) }
        if (newMuted) {
            ttsController.stop()
        }
    }

    fun startLiveConversation() {
        stopAllAudioAndCaptures()
        _liveState.update {
            it.copy(
                isSessionActive = true,
                isPaused = false,
                isProcessingTurn = false,
                errorMessage = null
            )
        }
        beginLiveListeningForActiveSpeaker()
    }

    fun pauseLiveConversation() {
        ttsController.stop()
        audioCapture.pause()
        _liveState.update { it.copy(isPaused = true, isListening = false) }
    }

    fun resumeLiveConversation() {
        if (!_liveState.value.isSessionActive) {
            startLiveConversation()
            return
        }
        _liveState.update { it.copy(isPaused = false, errorMessage = null) }
        beginLiveListeningForActiveSpeaker()
    }

    fun stopLiveConversation() {
        liveTurnJob?.cancel()
        audioCapture.cancel()
        ttsController.stop()
        _liveState.update {
            it.copy(
                isSessionActive = false,
                isPaused = false,
                isListening = false,
                isProcessingTurn = false
            )
        }
    }

    fun clearLiveConversation() {
        _liveState.update { it.copy(turns = emptyList(), errorMessage = null) }
    }

    private fun beginLiveListeningForActiveSpeaker() {
        val state = _liveState.value
        if (!state.isSessionActive || state.isPaused || state.isProcessingTurn) return
        ttsController.stop()
        _liveState.update { it.copy(isListening = true, errorMessage = null) }

        audioCapture.startRecording(
            enableSilenceDetection = true,
            onSilenceDetected = {
                viewModelScope.launch(Dispatchers.Main) {
                    submitCurrentLiveTurn()
                }
            },
            onError = { msg ->
                _liveState.update {
                    it.copy(isListening = false, isPaused = true, errorMessage = msg)
                }
            }
        )
    }

    fun submitCurrentLiveTurn() {
        val state = _liveState.value
        if (!state.isListening || state.isProcessingTurn) return
        val wavBytes = audioCapture.stopAndBuildWav()
        _liveState.update { it.copy(isListening = false) }

        if (wavBytes == null || wavBytes.size <= 44) {
            if (_liveState.value.isSessionActive && !_liveState.value.isPaused) {
                beginLiveListeningForActiveSpeaker()
            }
            return
        }

        val speaker = state.activeSpeaker
        val srcLang = if (speaker == LiveSpeaker.PERSON_A) state.personALanguage else state.personBLanguage
        val tgtLang = if (speaker == LiveSpeaker.PERSON_A) state.personBLanguage else state.personALanguage
        val script = _voiceState.value.balochiScript

        if (liveTurnJob?.isActive == true) return
        liveTurnJob = viewModelScope.launch {
            _liveState.update { it.copy(isProcessingTurn = true, errorMessage = null) }
            val result = aiService.translateAudio(wavBytes, srcLang, tgtLang, script)

            result.onSuccess { output ->
                val turn = LiveTurn(
                    id = UUID.randomUUID().toString(),
                    speaker = speaker,
                    sourceLanguage = srcLang,
                    targetLanguage = tgtLang,
                    sourceText = output.detectedSourceText,
                    translatedText = output.translatedText,
                    balochiLatinText = output.balochiLatinText,
                    balochiArabicText = output.balochiArabicText,
                    isUnclear = output.isUnclear,
                    uncertaintyReason = output.uncertaintyReason
                )
                val nextSpeaker = if (speaker == LiveSpeaker.PERSON_A) LiveSpeaker.PERSON_B else LiveSpeaker.PERSON_A
                _liveState.update {
                    it.copy(
                        isProcessingTurn = false,
                        turns = it.turns + turn,
                        activeSpeaker = if (output.isUnclear) speaker else nextSpeaker
                    )
                }

                val latest = _liveState.value
                if (latest.isSessionActive && !latest.isPaused) {
                    if (!latest.isMuted && !output.isUnclear) {
                        val profile = currentProfile()
                        ttsController.speak(
                            text = output.translatedText,
                            language = tgtLang,
                            speed = (profile?.voiceSpeed ?: 1.0).toFloat(),
                            volume = (profile?.voiceVolume ?: 1.0).toFloat(),
                            onComplete = {
                                viewModelScope.launch(Dispatchers.Main) {
                                    val after = _liveState.value
                                    if (after.isSessionActive && !after.isPaused && !after.isProcessingTurn) {
                                        beginLiveListeningForActiveSpeaker()
                                    }
                                }
                            }
                        )
                    } else {
                        beginLiveListeningForActiveSpeaker()
                    }
                }

                val status = if (output.isUnclear) "UNCLEAR" else "SUCCESS"
                viewModelScope.launch(Dispatchers.IO) {
                    repository.logUsageEvent(currentUserId, TranslationMode.LIVE, srcLang, tgtLang, status, output.latencyMs)
                    if (!output.isUnclear) {
                        repository.saveTranslation(currentUserId, output, script, TranslationMode.LIVE)
                    }
                }
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Live translation error."
                _liveState.update {
                    it.copy(isProcessingTurn = false, isPaused = true, errorMessage = msg)
                }
                viewModelScope.launch(Dispatchers.IO) {
                    repository.logUsageEvent(currentUserId, TranslationMode.LIVE, srcLang, tgtLang, "ERROR", 0L, msg)
                }
            }
        }
    }

    // --- Text Mode ---

    fun setTextLanguages(source: AppLanguage, target: AppLanguage) {
        if (source == target) return
        _textState.update { it.copy(sourceLanguage = source, targetLanguage = target, errorMessage = null) }
    }

    fun swapTextLanguages() {
        _textState.update {
            it.copy(
                sourceLanguage = it.targetLanguage,
                targetLanguage = it.sourceLanguage,
                errorMessage = null
            )
        }
    }

    fun updateTextInput(input: String) {
        _textState.update { it.copy(inputText = input, errorMessage = null) }
    }

    fun translateTextInput() {
        if (textTranslationJob?.isActive == true) return
        val state = _textState.value
        val script = _voiceState.value.balochiScript
        textTranslationJob = viewModelScope.launch {
            _textState.update { it.copy(isTranslating = true, errorMessage = null) }
            val result = aiService.translateText(
                text = state.inputText,
                sourceLanguage = state.sourceLanguage,
                targetLanguage = state.targetLanguage,
                balochiScript = script
            )
            result.onSuccess { output ->
                _textState.update { it.copy(isTranslating = false, result = output, errorMessage = null) }
                val status = if (output.isUnclear) "UNCLEAR" else "SUCCESS"
                viewModelScope.launch(Dispatchers.IO) {
                    repository.logUsageEvent(
                        currentUserId,
                        TranslationMode.TEXT,
                        state.sourceLanguage,
                        state.targetLanguage,
                        status,
                        output.latencyMs
                    )
                    if (!output.isUnclear) {
                        repository.saveTranslation(currentUserId, output, script, TranslationMode.TEXT)
                    }
                }
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Text translation failed."
                _textState.update { it.copy(isTranslating = false, errorMessage = msg) }
                viewModelScope.launch(Dispatchers.IO) {
                    repository.logUsageEvent(
                        currentUserId,
                        TranslationMode.TEXT,
                        state.sourceLanguage,
                        state.targetLanguage,
                        "ERROR",
                        0L,
                        msg
                    )
                }
            }
        }
    }

    // --- History & Playback ---

    fun openHistoryRecordInText(record: TranslationRecord) {
        val output = TranslationOutput(
            sourceLanguage = record.sourceLanguageEnum(),
            targetLanguage = record.targetLanguageEnum(),
            detectedSourceText = record.sourceText,
            translatedText = record.translatedText,
            balochiLatinText = record.balochiLatinText,
            balochiArabicText = record.balochiArabicText,
            isUnclear = !record.uncertaintyNote.isNullOrBlank(),
            uncertaintyReason = record.uncertaintyNote
        )
        _textState.update {
            it.copy(
                sourceLanguage = record.sourceLanguageEnum(),
                targetLanguage = record.targetLanguageEnum(),
                inputText = record.sourceText,
                result = output,
                errorMessage = null
            )
        }
    }

    fun deleteHistoryRecord(translationId: String) {
        viewModelScope.launch {
            repository.deleteTranslation(currentUserId, translationId)
                .onFailure { err ->
                    _statusBanner.value = err.localizedMessage ?: "Unable to delete translation."
                }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory(currentUserId)
                .onSuccess { _statusBanner.value = "Translation history cleared." }
                .onFailure { err ->
                    _statusBanner.value = err.localizedMessage ?: "Failed to clear history."
                }
        }
    }

    fun saveUserPreferences(
        defaultSource: AppLanguage,
        defaultTarget: AppLanguage,
        preferredScript: BalochiScript,
        voiceSpeed: Double,
        voiceVolume: Double,
        themeMode: ThemeMode
    ) {
        if (defaultSource == defaultTarget) {
            _statusBanner.value = "Default source and target languages cannot be the same."
            return
        }
        viewModelScope.launch {
            repository.updatePreferences(
                userId = currentUserId,
                defaultSourceLang = defaultSource,
                defaultTargetLang = defaultTarget,
                preferredBalochiScript = preferredScript,
                voiceSpeed = voiceSpeed,
                voiceVolume = voiceVolume,
                themeMode = themeMode
            ).onSuccess {
                _voiceState.update { it.copy(balochiScript = preferredScript) }
                _statusBanner.value = "Preferences saved."
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Failed to save preferences."
            }
        }
    }

    fun speakText(text: String, language: AppLanguage) {
        audioCapture.cancel()
        val profile = currentProfile()
        ttsController.speak(
            text = text,
            language = language,
            speed = (profile?.voiceSpeed ?: 1.0).toFloat(),
            volume = (profile?.voiceVolume ?: 1.0).toFloat()
        )
    }

    fun pauseSpeech() = ttsController.pause()
    fun resumeSpeech() = ttsController.resume()
    fun stopSpeech() = ttsController.stop()
    fun replaySpeech() = ttsController.replay()
    fun clearTtsNotice() = ttsController.clearUnavailableNotice()
    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun resetApiKeyValidationState() {
        _apiKeyValidationState.value = ApiKeyValidationState.Idle
    }

    fun verifyAndSaveApiKey(rawKey: String) {
        val cleanKey = rawKey.trim()
        if (cleanKey.isEmpty()) {
            _apiKeyValidationState.value =
                ApiKeyValidationState.Error("Please paste or enter a valid Gemini API key.")
            return
        }
        viewModelScope.launch {
            _apiKeyValidationState.value = ApiKeyValidationState.Testing
            aiService.validateApiKey(cleanKey)
                .onSuccess { details ->
                    apiKeyStore.saveApiKey(cleanKey)
                    _apiKeyValidationState.value = ApiKeyValidationState.Verified(details)
                    _voiceState.update { it.copy(errorMessage = null) }
                    _liveState.update { it.copy(errorMessage = null) }
                    _textState.update { it.copy(errorMessage = null) }
                    _statusBanner.value = "Gemini API key verified and saved."
                }
                .onFailure { err ->
                    _apiKeyValidationState.value = ApiKeyValidationState.Error(
                        err.localizedMessage ?: "Failed to verify Gemini API key."
                    )
                }
        }
    }

    fun clearCustomApiKey() {
        apiKeyStore.clearApiKey()
        _apiKeyValidationState.value = ApiKeyValidationState.Idle
        _statusBanner.value = "Custom Gemini API key removed. Using Firebase AI Logic."
    }

    fun stopAllAudioAndCaptures() {
        usingNativeRecognizerForVoice = false
        speechRecognizer.stop()
        audioCapture.cancel()
        ttsController.stop()
        _nativeRms.value = 0f
        if (_liveState.value.isSessionActive) {
            _liveState.update {
                it.copy(isSessionActive = false, isPaused = false, isListening = false)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizer.stop()
        audioCapture.cancel()
        ttsController.shutdown()
    }

    private companion object {
        const val TAG = "TranslatorVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
