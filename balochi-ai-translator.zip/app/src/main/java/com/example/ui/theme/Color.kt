package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Midnight Navy & Charcoal Dark Palette
val MidnightBg = Color(0xFF070B19)
val DeepNavySurface = Color(0xFF0E162B)
val GlassCardDark = Color(0xFF15203B)
val GlassCardElevated = Color(0xFF1B294B)
val SubtleBorderDark = Color(0xFF2B3D68)

// Luminous Cyan, Sapphire Blue & Subtle Purple Accents
val LuminousCyan = Color(0xFF00E5FF)
val CyanMuted = Color(0xFF22D3EE)
val ElectricBlue = Color(0xFF3B82F6)
val DeepSapphire = Color(0xFF1D4ED8)
val SoftViolet = Color(0xFF8B5CF6)
val VioletGlow = Color(0xFFA78BFA)

// Semantic & Status Colors
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val AmberWarning = Color(0xFFF59E0B)
val CoralError = Color(0xFFF87171)
val EmeraldSuccess = Color(0xFF34D399)

// Crisp Daylight Light Palette (for optional Light Theme setting)
val LightBg = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8EFFA)
val LightBorder = Color(0xFFCBD5E1)
val PrimaryBlueLight = Color(0xFF0284C7)
val SecondaryBlueLight = Color(0xFF2563EB)
val TertiaryVioletLight = Color(0xFF6D28D9)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
