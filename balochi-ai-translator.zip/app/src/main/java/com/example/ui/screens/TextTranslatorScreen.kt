package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppLanguage
import com.example.ui.TranslatorViewModel
import com.example.ui.components.BalochiScriptSelectorRow
import com.example.ui.components.LanguageSelectorBar
import com.example.ui.components.TranslationOutputCard

@Composable
fun TextTranslatorScreen(
    viewModel: TranslatorViewModel,
    onShowMessage: (String) -> Unit,
    onOpenApiKeyDialog: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    val textState by viewModel.textState.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val ttsState by viewModel.ttsState.collectAsStateWithLifecycle()
    val hasCustomApiKey by viewModel.hasCustomApiKey.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            LanguageSelectorBar(
                sourceLanguage = textState.sourceLanguage,
                targetLanguage = textState.targetLanguage,
                onSelectSource = { src ->
                    val tgt = if (src == textState.targetLanguage) textState.sourceLanguage else textState.targetLanguage
                    viewModel.setTextLanguages(src, tgt)
                },
                onSelectTarget = { tgt ->
                    viewModel.setTextLanguages(textState.sourceLanguage, tgt)
                },
                onSwap = { viewModel.swapTextLanguages() }
            )

            if (textState.sourceLanguage == AppLanguage.BALOCHI ||
                textState.targetLanguage == AppLanguage.BALOCHI
            ) {
                BalochiScriptSelectorRow(
                    selectedScript = voiceState.balochiScript,
                    onSelectScript = { viewModel.setBalochiScriptQuick(it) }
                )
            }

            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Enter ${textState.sourceLanguage.displayName}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row {
                            IconButton(
                                onClick = {
                                    clipboard.getText()?.text?.let { pasted ->
                                        viewModel.updateTextInput(pasted.take(5000))
                                    }
                                },
                                modifier = Modifier.testTag("text_paste_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ContentPaste,
                                    contentDescription = "Paste text",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (textState.inputText.isNotEmpty()) {
                                IconButton(
                                    onClick = { viewModel.updateTextInput("") },
                                    modifier = Modifier.testTag("text_clear_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Clear,
                                        contentDescription = "Clear text",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = textState.inputText,
                        onValueChange = { if (it.length <= 5000) viewModel.updateTextInput(it) },
                        placeholder = {
                            Text("Type or paste a sentence or paragraph…")
                        },
                        minLines = 4,
                        maxLines = 8,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("text_input_field")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${textState.inputText.length} / 5000",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = { viewModel.translateTextInput() },
                            enabled = textState.inputText.isNotBlank() && !textState.isTranslating,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("text_translate_button")
                        ) {
                            if (textState.isTranslating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Translate,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.size(8.dp))
                            Text(if (textState.isTranslating) "Translating…" else "Translate")
                        }
                    }
                }
            }

            if (!textState.errorMessage.isNullOrBlank()) {
                val isKeyError = !hasCustomApiKey || viewModel.isKeyOrAuthError(textState.errorMessage)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = textState.errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (textState.inputText.isNotBlank()) {
                                FilledTonalButton(
                                    onClick = { viewModel.translateTextInput() },
                                    enabled = !textState.isTranslating,
                                    modifier = Modifier.testTag("text_retry_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Refresh,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Retry")
                                }
                            }
                            if (isKeyError) {
                                TextButton(
                                    onClick = onOpenApiKeyDialog,
                                    modifier = Modifier.testTag("error_configure_api_key_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Key,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Add / Update Gemini API Key")
                                }
                            }
                        }
                    }
                }
            }

            textState.result?.let { output ->
                TranslationOutputCard(
                    output = output,
                    ttsState = ttsState,
                    onPlayAudio = { txt, lang -> viewModel.speakText(txt, lang) },
                    onPauseAudio = { viewModel.pauseSpeech() },
                    onResumeAudio = { viewModel.resumeSpeech() },
                    onStopAudio = { viewModel.stopSpeech() },
                    onReplayAudio = { viewModel.replaySpeech() },
                    onCopy = { txt ->
                        clipboard.setText(AnnotatedString(txt))
                        onShowMessage("Translation copied to clipboard")
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
