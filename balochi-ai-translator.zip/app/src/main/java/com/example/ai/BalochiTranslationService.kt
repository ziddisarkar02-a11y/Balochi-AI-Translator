package com.example.ai

import android.util.Base64
import android.util.Log
import com.example.data.GeminiApiKeyStore
import com.example.model.AppLanguage
import com.example.model.BalochiScript
import com.example.model.TranslationOutput
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.ConnectionPool
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class BalochiTranslationService(
    private val apiKeyStore: GeminiApiKeyStore? = null
) {

    private val requestMutex = Mutex()
    private val recentRequestTimestamps = ArrayDeque<Long>()

    @Volatile
    private var preferredDirectModel: String? = apiKeyStore?.getPreferredModel()

    private val dnsLookupClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(2500, TimeUnit.MILLISECONDS)
            .readTimeout(2500, TimeUnit.MILLISECONDS)
            .build()
    }

    private val resilientDns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            return try {
                // Prefer IPv4 addresses first to avoid mobile/emulator IPv6 connect blackhole delays
                Dns.SYSTEM.lookup(hostname).sortedBy { if (it is Inet4Address) 0 else if (it is Inet6Address) 2 else 1 }
            } catch (systemErr: UnknownHostException) {
                if (hostname == "8.8.8.8" || hostname == "1.1.1.1") {
                    throw systemErr
                }
                resolveViaDoH("https://8.8.8.8/resolve?name=$hostname&type=A")
                    ?: resolveViaDoH("https://1.1.1.1/dns-query?name=$hostname&type=A")
                    ?: throw systemErr
            }
        }
    }

    private fun resolveViaDoH(dohUrl: String): List<InetAddress>? {
        return try {
            val req = Request.Builder()
                .url(dohUrl)
                .addHeader("Accept", "application/dns-json")
                .get()
                .build()
            dnsLookupClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = resp.body?.string().orEmpty()
                val answers = JSONObject(body).optJSONArray("Answer") ?: return null
                val result = mutableListOf<InetAddress>()
                for (i in 0 until answers.length()) {
                    val ans = answers.optJSONObject(i) ?: continue
                    if (ans.optInt("type") == 1) {
                        val ip = ans.optString("data").trim()
                        if (ip.isNotEmpty()) {
                            result.add(InetAddress.getByName(ip))
                        }
                    }
                }
                result.takeIf { it.isNotEmpty() }
            }
        } catch (_: Exception) {
            null
        }
    }

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(resilientDns)
            .connectionPool(ConnectionPool(5, 5, TimeUnit.MINUTES))
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private fun orderedDirectModels(): List<String> {
        val preferred = preferredDirectModel ?: apiKeyStore?.getPreferredModel()
        return if (preferred != null && preferred in DIRECT_API_MODEL_CANDIDATES) {
            listOf(preferred) + DIRECT_API_MODEL_CANDIDATES.filter { it != preferred }
        } else {
            DIRECT_API_MODEL_CANDIDATES
        }
    }

    private fun rememberPreferredModel(modelId: String) {
        preferredDirectModel = modelId
        apiKeyStore?.savePreferredModel(modelId)
    }

    suspend fun prewarmConnection() {
        withContext(Dispatchers.IO) {
            try {
                resilientDns.lookup("generativelanguage.googleapis.com")
            } catch (_: Exception) {
            }
        }
    }

    private val translationSchema = Schema.obj(
        properties = mapOf(
            "detectedSourceText" to Schema.string(
                description = "Accurate transcription or normalized source sentence in the source language."
            ),
            "translatedText" to Schema.string(
                description = "Primary translated sentence in the target language respecting Balochi script preference."
            ),
            "balochiLatinText" to Schema.string(
                description = "Balochi sentence in clean Latin transliteration if source or target is Balochi; empty string otherwise."
            ),
            "balochiArabicText" to Schema.string(
                description = "Balochi sentence in natural Arabic-based Balochi script if source or target is Balochi; empty string otherwise."
            ),
            "isUnclear" to Schema.boolean(
                description = "True ONLY if audio or text contains unclear, unintelligible, or ambiguous words that should not be guessed."
            ),
            "uncertaintyReason" to Schema.string(
                description = "Short polite message asking the user to repeat or clarify unclear words, or empty string if clear."
            ),
            "registerNote" to Schema.string(
                description = "Optional concise dialect or tone note when helpful; empty string by default."
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.2f
                responseMimeType = "application/json"
                responseSchema = translationSchema
            },
            systemInstruction = content {
                text(SPECIALIZED_SYSTEM_INSTRUCTION)
            }
        )
    }

    suspend fun validateApiKey(candidateKey: String): Result<String> {
        val cleanKey = candidateKey.trim()
        if (cleanKey.isEmpty()) {
            return Result.failure(IllegalArgumentException("Please enter a valid Gemini API key."))
        }

        return withContext(Dispatchers.IO) {
            try {
                withTimeout(30_000L) {
                    var lastTransientError: String? = null
                    var sawTransientServerBusy = false

                    for (modelId in orderedDirectModels()) {
                        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent"
                        val bodyJson = JSONObject().apply {
                            put(
                                "contents",
                                JSONArray().put(
                                    JSONObject().apply {
                                        put("role", "user")
                                        put(
                                            "parts",
                                            JSONArray().put(JSONObject().put("text", "Reply with OK"))
                                        )
                                    }
                                )
                            )
                            put(
                                "generationConfig",
                                JSONObject().put("maxOutputTokens", 8)
                            )
                        }
                        val request = Request.Builder()
                            .url(url)
                            .addHeader("x-goog-api-key", cleanKey)
                            .addHeader("Content-Type", "application/json")
                            .post(bodyJson.toString().toRequestBody(JSON_MEDIA_TYPE))
                            .build()

                        httpClient.newCall(request).execute().use { resp ->
                            val respBody = resp.body?.string().orEmpty()
                            if (resp.isSuccessful) {
                                rememberPreferredModel(modelId)
                                return@withTimeout Result.success("Verified ($modelId)")
                            }
                            if (resp.code in RETRYABLE_HTTP_CODES) {
                                if (resp.code != 404) {
                                    sawTransientServerBusy = true
                                }
                                lastTransientError = extractRestErrorMessage(resp.code, respBody)
                                continue
                            }
                            val msg = extractRestErrorMessage(resp.code, respBody)
                            return@withTimeout Result.failure(IllegalStateException(msg))
                        }
                    }

                    // If generateContent failed only due to temporary 503/429 high demand, verify key directly via /v1beta/models
                    if (sawTransientServerBusy) {
                        val modelsReq = Request.Builder()
                            .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=5")
                            .addHeader("x-goog-api-key", cleanKey)
                            .get()
                            .build()
                        httpClient.newCall(modelsReq).execute().use { resp ->
                            val respBody = resp.body?.string().orEmpty()
                            if (resp.isSuccessful) {
                                return@withTimeout Result.success("Key verified (high-demand fallback enabled)")
                            }
                            if (resp.code in listOf(400, 401, 403)) {
                                return@withTimeout Result.failure(
                                    IllegalStateException(extractRestErrorMessage(resp.code, respBody))
                                )
                            }
                        }
                    }

                    Result.failure(
                        IllegalStateException(
                            lastTransientError ?: "No compatible Gemini model found for this key."
                        )
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Result.failure(IllegalStateException("Verification timed out. Check your internet connection."))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "API key verification failed", e)
                Result.failure(IllegalStateException(friendlyAiError(e, usingCustomKey = true)))
            }
        }
    }

    suspend fun translateText(
        text: String,
        sourceLanguage: AppLanguage,
        targetLanguage: AppLanguage,
        balochiScript: BalochiScript
    ): Result<TranslationOutput> {
        val cleanInput = text.trim()
        if (cleanInput.isEmpty()) {
            return Result.failure(IllegalArgumentException("Please enter text to translate."))
        }
        if (sourceLanguage == targetLanguage) {
            return Result.failure(IllegalArgumentException("Source and target languages must differ."))
        }

        val gateError = checkRateLimit()
        if (gateError != null) return Result.failure(IllegalStateException(gateError))

        val prompt = buildTranslationPrompt(
            sourceLanguage = sourceLanguage,
            targetLanguage = targetLanguage,
            balochiScript = balochiScript,
            inputText = cleanInput,
            isAudio = false
        )

        val customKey = apiKeyStore?.getApiKey().orEmpty()
        val startMs = System.currentTimeMillis()
        return try {
            val rawJson = if (customKey.isNotBlank()) {
                callDirectGeminiApi(
                    apiKey = customKey,
                    prompt = prompt,
                    wavAudioBytes = null
                )
            } else {
                val response = withTimeout(60_000L) {
                    model.generateContent(prompt)
                }
                response.text
                    ?: throw IllegalStateException("Translation model returned an empty response.")
            }
            val latencyMs = System.currentTimeMillis() - startMs
            Result.success(
                parseStructuredTranslation(
                    rawJson = rawJson,
                    sourceLanguage = sourceLanguage,
                    targetLanguage = targetLanguage,
                    fallbackSourceText = cleanInput,
                    latencyMs = latencyMs
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Text translation timed out", e)
            Result.failure(IllegalStateException("Translation timed out. Please check your connection and try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Text translation failed", e)
            Result.failure(IllegalStateException(friendlyAiError(e, customKey.isNotBlank())))
        }
    }

    suspend fun translateAudio(
        wavAudioBytes: ByteArray,
        sourceLanguage: AppLanguage,
        targetLanguage: AppLanguage,
        balochiScript: BalochiScript
    ): Result<TranslationOutput> {
        if (wavAudioBytes.size <= 44) {
            return Result.failure(IllegalArgumentException("No audio was captured. Please speak clearly and try again."))
        }
        if (wavAudioBytes.size > 18 * 1024 * 1024) {
            return Result.failure(IllegalArgumentException("Audio clip is too long. Please keep each turn under 4 minutes."))
        }
        if (sourceLanguage == targetLanguage) {
            return Result.failure(IllegalArgumentException("Source and target languages must differ."))
        }

        val gateError = checkRateLimit()
        if (gateError != null) return Result.failure(IllegalStateException(gateError))

        val prompt = buildTranslationPrompt(
            sourceLanguage = sourceLanguage,
            targetLanguage = targetLanguage,
            balochiScript = balochiScript,
            inputText = null,
            isAudio = true
        )

        val customKey = apiKeyStore?.getApiKey().orEmpty()
        val startMs = System.currentTimeMillis()
        return try {
            val rawJson = if (customKey.isNotBlank()) {
                callDirectGeminiApi(
                    apiKey = customKey,
                    prompt = prompt,
                    wavAudioBytes = wavAudioBytes
                )
            } else {
                val response = withTimeout(60_000L) {
                    model.generateContent(
                        content {
                            inlineData(wavAudioBytes, "audio/wav")
                            text(prompt)
                        }
                    )
                }
                response.text
                    ?: throw IllegalStateException("Audio translation model returned an empty response.")
            }
            val latencyMs = System.currentTimeMillis() - startMs
            Result.success(
                parseStructuredTranslation(
                    rawJson = rawJson,
                    sourceLanguage = sourceLanguage,
                    targetLanguage = targetLanguage,
                    fallbackSourceText = "(Audio input)",
                    latencyMs = latencyMs
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Audio translation timed out", e)
            Result.failure(IllegalStateException("Voice translation timed out. Please try a shorter sentence or check your network."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Audio translation failed", e)
            Result.failure(IllegalStateException(friendlyAiError(e, customKey.isNotBlank())))
        }
    }

    private suspend fun callDirectGeminiApi(
        apiKey: String,
        prompt: String,
        wavAudioBytes: ByteArray?
    ): String = withContext(Dispatchers.IO) {
        withTimeout(35_000L) {
            val parts = JSONArray()
            if (wavAudioBytes != null) {
                val base64Audio = Base64.encodeToString(wavAudioBytes, Base64.NO_WRAP)
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject()
                            .put("mime_type", "audio/wav")
                            .put("data", base64Audio)
                    )
                )
            }
            parts.put(JSONObject().put("text", prompt))

            val responseSchema = buildRestResponseSchema()
            val systemInstructionObj = JSONObject().put(
                "parts",
                JSONArray().put(JSONObject().put("text", SPECIALIZED_SYSTEM_INSTRUCTION))
            )
            val contentsArr = JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", parts)
            )

            var lastFallbackError: String? = null
            for (modelId in orderedDirectModels()) {
                val respResult = executeDirectModelCall(
                    modelId = modelId,
                    apiKey = apiKey,
                    systemInstructionObj = systemInstructionObj,
                    contentsArr = contentsArr,
                    responseSchema = responseSchema,
                    includeThinkingConfig = true
                )
                if (respResult.isSuccess) {
                    rememberPreferredModel(modelId)
                    return@withTimeout respResult.getOrThrow()
                }
                val err = respResult.exceptionOrNull()
                if (err is ThinkingUnsupportedException) {
                    val retryNoThinking = executeDirectModelCall(
                        modelId = modelId,
                        apiKey = apiKey,
                        systemInstructionObj = systemInstructionObj,
                        contentsArr = contentsArr,
                        responseSchema = responseSchema,
                        includeThinkingConfig = false
                    )
                    if (retryNoThinking.isSuccess) {
                        rememberPreferredModel(modelId)
                        return@withTimeout retryNoThinking.getOrThrow()
                    }
                    val noThinkErr = retryNoThinking.exceptionOrNull()
                    if (noThinkErr is RetryableModelHttpException) {
                        lastFallbackError = noThinkErr.message
                        continue
                    }
                    throw (noThinkErr ?: IllegalStateException("Gemini API request failed."))
                }
                if (err is RetryableModelHttpException) {
                    lastFallbackError = err.message
                    continue
                }
                throw (err ?: IllegalStateException("Gemini API request failed."))
            }
            throw IllegalStateException(lastFallbackError ?: "No compatible Gemini model available right now.")
        }
    }

    private fun executeDirectModelCall(
        modelId: String,
        apiKey: String,
        systemInstructionObj: JSONObject,
        contentsArr: JSONArray,
        responseSchema: JSONObject,
        includeThinkingConfig: Boolean
    ): Result<String> {
        val genConfig = JSONObject()
            .put("maxOutputTokens", 768)
            .put("response_mime_type", "application/json")
            .put("response_schema", responseSchema)

        if (!modelId.startsWith("gemini-3")) {
            genConfig.put("temperature", 0.15)
        }

        if (includeThinkingConfig) {
            when {
                modelId.startsWith("gemini-2.5") ->
                    genConfig.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                modelId.startsWith("gemini-3") ->
                    genConfig.put("thinkingConfig", JSONObject().put("thinkingLevel", "MINIMAL"))
            }
        }

        val payload = JSONObject()
            .put("system_instruction", systemInstructionObj)
            .put("contents", contentsArr)
            .put("generationConfig", genConfig)

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        httpClient.newCall(request).execute().use { resp ->
            val respText = resp.body?.string().orEmpty()
            if (resp.isSuccessful) {
                val root = JSONObject(respText)
                val candidates = root.optJSONArray("candidates")
                val first = candidates?.optJSONObject(0)
                val contentObj = first?.optJSONObject("content")
                val respParts = contentObj?.optJSONArray("parts")
                val textOut = respParts?.optJSONObject(0)?.optString("text")?.trim()
                if (!textOut.isNullOrBlank()) {
                    return Result.success(textOut)
                }
                return Result.failure(IllegalStateException("Gemini returned an empty translation response."))
            }
            if (resp.code == 400 && includeThinkingConfig && respText.contains("thinking", ignoreCase = true)) {
                return Result.failure(ThinkingUnsupportedException())
            }
            if (resp.code in RETRYABLE_HTTP_CODES) {
                return Result.failure(RetryableModelHttpException(extractRestErrorMessage(resp.code, respText)))
            }
            return Result.failure(IllegalStateException(extractRestErrorMessage(resp.code, respText)))
        }
    }

    private class RetryableModelHttpException(message: String) : Exception(message)
    private class ThinkingUnsupportedException : Exception()

    private fun buildRestResponseSchema(): JSONObject = JSONObject().apply {
        put("type", "OBJECT")
        put(
            "properties",
            JSONObject().apply {
                put("detectedSourceText", JSONObject().put("type", "STRING"))
                put("translatedText", JSONObject().put("type", "STRING"))
                put("balochiLatinText", JSONObject().put("type", "STRING"))
                put("balochiArabicText", JSONObject().put("type", "STRING"))
                put("isUnclear", JSONObject().put("type", "BOOLEAN"))
                put("uncertaintyReason", JSONObject().put("type", "STRING"))
                put("registerNote", JSONObject().put("type", "STRING"))
            }
        )
        put(
            "required",
            JSONArray(
                listOf(
                    "detectedSourceText",
                    "translatedText",
                    "balochiLatinText",
                    "balochiArabicText",
                    "isUnclear",
                    "uncertaintyReason",
                    "registerNote"
                )
            )
        )
    }

    private fun extractRestErrorMessage(code: Int, rawBody: String): String {
        val parsed = try {
            JSONObject(rawBody).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Exception) {
            ""
        }
        return when (code) {
            400, 401, 403 -> if (parsed.isNotBlank()) "Gemini API key error ($code): $parsed" else "Invalid or unauthorized Gemini API key ($code)."
            429 -> "Gemini API rate limit or quota exceeded (429). Please wait or check your Google AI Studio billing/quota."
            else -> if (parsed.isNotBlank()) "Gemini error ($code): $parsed" else "Gemini API request failed ($code)."
        }
    }

    private suspend fun checkRateLimit(): String? = requestMutex.withLock {
        val now = System.currentTimeMillis()
        while (recentRequestTimestamps.isNotEmpty() && now - recentRequestTimestamps.first() > 60_000L) {
            recentRequestTimestamps.removeFirst()
        }
        if (recentRequestTimestamps.size >= MAX_REQUESTS_PER_MINUTE) {
            "You have reached the per-minute translation limit. Please wait a few seconds before trying again."
        } else {
            recentRequestTimestamps.addLast(now)
            null
        }
    }

    private fun buildTranslationPrompt(
        sourceLanguage: AppLanguage,
        targetLanguage: AppLanguage,
        balochiScript: BalochiScript,
        inputText: String?,
        isAudio: Boolean
    ): String {
        val scriptGuidance = when (balochiScript) {
            BalochiScript.LATIN ->
                "For any Balochi output, write `translatedText` in clean, natural Balochi Latin transliteration (and also populate `balochiLatinText` and `balochiArabicText`)."
            BalochiScript.ARABIC ->
                "For any Balochi output, write `translatedText` in natural Arabic-based Balochi script (and also populate `balochiArabicText` and `balochiLatinText`)."
            BalochiScript.BOTH ->
                "For any Balochi output, provide the primary Balochi translation in `translatedText` (Latin transliteration first, or Arabic script alongside) AND populate both `balochiLatinText` and `balochiArabicText`."
        }

        val taskHeader = if (isAudio) {
            """
            Listen carefully to the attached ${sourceLanguage.displayName} speech audio.
            1. Transcribe the exact spoken ${sourceLanguage.displayName} sentence into `detectedSourceText` (if Balochi, format according to script preference and also fill `balochiLatinText` / `balochiArabicText`).
            2. If the audio is silent, noisy, cut off, or contains unclear ${sourceLanguage.displayName} words, DO NOT GUESS or invent a translation: set `isUnclear = true`, explain politely what was unclear in `uncertaintyReason` asking the user to repeat or edit, and set `translatedText` to a brief clarification prompt in ${targetLanguage.displayName}.
            3. If clear, translate accurately and naturally from ${sourceLanguage.displayName} into ${targetLanguage.displayName}.
            """.trimIndent()
        } else {
            """
            Analyze and translate the following ${sourceLanguage.displayName} input into ${targetLanguage.displayName}.
            1. Put the cleaned/normalized source sentence in `detectedSourceText`.
            2. If the input contains unintelligible fragments or ambiguous regional Balochi terms you are uncertain about, set `isUnclear = true`, clearly describe the uncertainty in `uncertaintyReason` asking the user to clarify, and do not invent missing meaning.
            3. Otherwise translate naturally and accurately into ${targetLanguage.displayName}.
            Input text:
            "$inputText"
            """.trimIndent()
        }

        return """
            $taskHeader

            Source language: ${sourceLanguage.displayName}
            Target language: ${targetLanguage.displayName}
            Balochi script preference: ${balochiScript.displayName}
            $scriptGuidance
        """.trimIndent()
    }

    private fun parseStructuredTranslation(
        rawJson: String,
        sourceLanguage: AppLanguage,
        targetLanguage: AppLanguage,
        fallbackSourceText: String,
        latencyMs: Long
    ): TranslationOutput {
        val cleaned = rawJson.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val obj = JSONObject(cleaned)
        val detectedSource = obj.optString("detectedSourceText").trim()
            .ifBlank { fallbackSourceText }
        val translated = obj.optString("translatedText").trim()
            .ifBlank { "Unable to generate a clear translation. Please repeat or rephrase." }
        val latin = obj.optString("balochiLatinText").trim().ifBlank { null }
        val arabic = obj.optString("balochiArabicText").trim().ifBlank { null }
        val isUnclear = obj.optBoolean("isUnclear", false)
        val uncertaintyReason = obj.optString("uncertaintyReason").trim().ifBlank { null }
        val registerNote = obj.optString("registerNote").trim().ifBlank { null }

        return TranslationOutput(
            sourceLanguage = sourceLanguage,
            targetLanguage = targetLanguage,
            detectedSourceText = detectedSource,
            translatedText = translated,
            balochiLatinText = latin,
            balochiArabicText = arabic,
            isUnclear = isUnclear,
            uncertaintyReason = uncertaintyReason,
            registerNote = registerNote,
            latencyMs = latencyMs
        )
    }

    private fun friendlyAiError(e: Exception, usingCustomKey: Boolean): String {
        val causes = generateSequence<Throwable>(e) { it.cause }.toList()
        if (causes.any { it is UnknownHostException }) {
            return "Internet or DNS connection failed. Check your Wi-Fi / mobile data (or Private DNS / VPN) and tap Retry."
        }
        if (causes.any { it is SocketTimeoutException || it is TimeoutCancellationException }) {
            return "Connection timed out. Please check your internet speed and tap Retry."
        }
        if (causes.any { it is ConnectException || it is IOException }) {
            return "Network connection interrupted. Please check your internet and tap Retry."
        }

        val raw = e.localizedMessage ?: e.message ?: "Translation service failed."
        return when {
            !usingCustomKey && (raw.contains("403") || raw.contains("AppCheck", ignoreCase = true)) ->
                "Firebase AI attestation failed (App Check). Tap \"Add Gemini API Key\" to connect directly with your Gemini API key."
            raw.contains("Unable to resolve host", ignoreCase = true) ||
                raw.contains("No address associated with hostname", ignoreCase = true) ->
                "Internet or DNS connection failed. Check your Wi-Fi / mobile data and tap Retry."
            raw.contains("429") || raw.contains("quota", ignoreCase = true) ->
                "Translation quota temporarily reached. Please wait a moment and try again."
            raw.contains("network", ignoreCase = true) || raw.contains("unavailable", ignoreCase = true) ->
                "Network connection interrupted. Please check your internet and tap Retry."
            else -> raw
        }
    }

    private companion object {
        const val TAG = "BalochiAiService"
        const val MAX_REQUESTS_PER_MINUTE = 25
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        val RETRYABLE_HTTP_CODES = setOf(404, 429, 500, 502, 503, 504)
        val DIRECT_API_MODEL_CANDIDATES = listOf(
            "gemini-3.5-flash-lite",
            "gemini-3.6-flash",
            "gemini-3.8-flash",
            "gemini-2.5-flash"
        )

        val SPECIALIZED_SYSTEM_INSTRUCTION = """
            You are an expert multilingual translator specializing in Balochi, English, and Urdu.

            Your highest priority is accurate Balochi translation.

            Understand conversational Balochi, regional vocabulary (including Makrani, Rakhshani, and Eastern/Sulaimani expressions), informal expressions, common phrases, and natural sentence structures.

            Translate meaning rather than blindly translating individual words.

            Preserve the speaker's original intention, tone, politeness, and context.

            Never replace Balochi with another language.

            Never silently translate unclear or missing words by guessing.

            If the source is Balochi, identify whether the input is understandable Balochi and translate it into the selected target language.

            If the user selects English, return natural English.

            If the user selects Urdu, return natural Urdu.

            If the user selects Balochi, return natural Balochi.

            Keep translations concise and natural unless the user provides a longer paragraph.

            When uncertain about a regional Balochi expression or unclear audio, clearly indicate uncertainty in `isUnclear` and `uncertaintyReason`.

            Do not add unnecessary explanations unless requested.

            Support both Balochi Latin transliteration and Arabic-based writing where appropriate.
        """.trimIndent()
    }
}
