# Balochi AI Translator

An Android AI-powered voice, live conversation, and text translation application built with **Kotlin**, **Jetpack Compose (Material 3)**, **Firebase AI Logic (Gemini)**, **Firebase Authentication**, **Firebase App Check**, and **Cloud Firestore**.

The application is engineered around **Balochi**, supporting seamless 6-way translation across exactly three languages:
- **Balochi** (Latin transliteration and Arabic-based script)
- **English**
- **Urdu**

---

## Core Features

1. **Voice Translation Mode**
   - Central animated microphone button with real-time RMS audio waveform visualization.
   - Supports **Tap to Speak**, **Pause / Resume**, **Translate**, and **Cancel**.
   - **Balochi & Fallback AI Audio Engine**: Because native Android `SpeechRecognizer` does not support Balochi, spoken Balochi (and any device without native speech recognition) is captured via `AudioRecord` (16 kHz mono WAV) and processed directly by Gemini multimodal audio (`gemini-3.8-flash`) via Firebase AI Logic.
   - **Live Partial Captions**: Uses Android `SpeechRecognizer` for real-time partial captions in English and Urdu when supported, with automatic fallback to AI Audio capture.
   - **Editable Transcript**: Users can review and edit recognized words before retranslating.
   - **Uncertainty Protection**: Gemini is instructed never to invent or guess unclear Balochi words; uncertain speech triggers a clarification prompt asking the speaker to repeat or edit.

2. **Live Voice Conversation Mode**
   - Dedicated two-way interpreter for **Person A ↔ Person B** (`Balochi ↔ English`, `Balochi ↔ Urdu`, `English ↔ Urdu`).
   - Controls: **Start Conversation**, **Pause / Resume**, **Stop Conversation**, **Clear Conversation**, **Swap Speakers**, and **Mute Translation Audio**.
   - Captures speech turns with automatic voice-activity silence detection (or manual **Send Turn**), translates via Gemini, displays bilingual captions, speaks the translation aloud via `TextToSpeech` (when available and unmuted), and hands the turn to the next speaker.

3. **Text Translation Mode**
   - Minimal text translation interface with paste/clear actions, 5,000-character limit, Balochi script toggle (`Latin`, `Arabic`, `Both`), copy, and TTS playback.

4. **Text-to-Speech (TTS) & Balochi Fallback**
   - Uses Android `TextToSpeech` with user-configured **Voice Speed** and **Voice Volume**, supporting **Play**, **Pause**, **Stop**, and **Replay**.
   - Checks device voice availability before speaking; if a natural Balochi (or Urdu) voice is unavailable on the device, displays a clear notice instead of speaking garbled English-accented audio.

5. **Private Cloud Translation History & Preferences**
   - Authenticated per-user persistence in **Cloud Firestore** (`/users/{userId}` and `/users/{userId}/translations/{translationId}`).
   - Real-time history with search, mode filters (`All`, `Voice`, `Live`, `Text`), copy, audio playback, individual delete, and clear all.
   - Telemetry logs in `/users/{userId}/usage_logs/{logId}` for latency and error monitoring.

---

## Firebase & Security Architecture

- **Authentication**: Uses Jetpack `CredentialManager` with Google Sign-In (`GetSignInWithGoogleOption` and silent `GetGoogleIdOption`). Email/Password or additional identity providers can be enabled manually in the Firebase Console if desired.
- **Zero Client-Side API Keys**: Gemini calls run through **Firebase AI Logic** (`Firebase.ai.generativeModel("gemini-3.8-flash")`) attested by **Firebase App Check** (debug provider via launch intent token in debug builds, reCAPTCHA Enterprise in release builds).
- **Cloud Firestore Rules (`firestore.rules`)**:
  - Default-deny catch-all at root.
  - Strict owner isolation (`request.auth.uid == userId`).
  - Field-level type, enum, length, and timestamp validation (`isValidUserProfile`, `isValidTranslationRecord`, `isValidUsageLog`).
  - Immutable `createdAt` and `userId` checks on profile updates.

---

## Setup & Deployment

1. **Firebase Provisioning**
   - `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml` are generated during AI Studio Firebase setup (`ProvisionFirebase` with `firestore` and `ai_logic`).
   - Do not commit API secrets to `.env` or source files; Firebase AI Logic uses App Check instead of `GEMINI_API_KEY`.

2. **Deploy Security Rules**
   - Rules are validated locally against the single-database Firestore emulator (`firebase.json` + `firestore.test.js`):
     ```bash
     FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js
     ```
   - Deploy `firestore.rules` to your provisioned Firestore database (`DeployRules`).

3. **Build & Test**
   ```bash
   gradle :app:compileDebugKotlin
   gradle :app:testDebugUnitTest
   ```

---

## Troubleshooting

- **HTTP 403 / App Check errors on AI calls**: Ensure Firebase setup included `ai_logic` and `configureAppCheck(this, intent)` executes at the start of `MainActivity.onCreate()`. Alternatively, tap the **Key** icon in the top bar (or **Profile & Settings → Add Gemini API Key**) to paste and verify your own Gemini API key, stored privately on-device.
- **Google Sign-In cancelled (`GetCredentialCancellationException`)**: Verify the signing certificate SHA-1/SHA-256 in `app/google-services.json` matches your keystore (`debug.keystore` for debug builds).
- **Microphone unavailable**: Grant `RECORD_AUDIO` permission when prompted and ensure no other app holds exclusive microphone focus.
- **No spoken audio for Balochi**: Most Android devices do not ship an offline/online Balochi TTS voice; the app intentionally displays a clear fallback notice while keeping written Balochi (Latin and/or Arabic script) visible.
